# -*- coding: utf-8 -*-
"""
资源中心 - 按分类展示所有内置py源
"""
import os
import json
import re

PY_DIR = "/storage/emulated/0/123/py"

# 源分类数据（由构建脚本生成）
SOURCE_CATEGORIES = {
    "成人": [],
    "吃瓜": [],
    "伦理": [],
    "成人动漫": [],
    "成人直播": [],
    "成人短剧": [],
    "成人听书": [],
    "未分类": [],
}

def _scan_local_sources():
    """扫描本地py目录（包括.sources隐藏目录），按分类整理源列表"""
    categories = {}
    scan_dirs = [PY_DIR, os.path.join(PY_DIR, ".sources")]
    for scan_dir in scan_dirs:
        if not os.path.exists(scan_dir):
            continue
        for filename in os.listdir(scan_dir):
            if not filename.endswith('.py'):
                continue
            skip_list = ['list_nav.py', 'list.py', 'list_with_remote.py', 
                         'password_center.py', 'site_checker.py', 'smart_loader.py',
                         'resource_center.py', 'wuye_movie.py', 'aowu_config.py', '__init__.py',
                         'mengnan.py', 'qisegu.py', 'gaoqing.py', 'gaokao.py',
                         'weimei.py', 'bainian_live.py', 'javdb_aowu.py', 'supjav.py']
            if filename in skip_list:
                continue
            match = re.match(r'\[(.+?)\](.+?)(🔞)?\.py$', filename)
            if match:
                category = match.group(1)
                name = match.group(2).strip()
            else:
                category = "未分类"
                name = filename.replace('.py', '')
            if category not in categories:
                categories[category] = []
            categories[category].append({
                'filename': filename,
                'name': name,
                'category': category,
                'size': os.path.getsize(os.path.join(scan_dir, filename)),
            })
    return categories

class Spider:
    """资源中心Spider"""
    filterable = False

    def __init__(self):
        self.ext = ""

    def init(self, extend=""):
        self.ext = extend

    def getName(self):
        return "📚 资源中心"

    def homeContent(self, filter):
        categories = _scan_local_sources()
        videos = []
        # 汇总卡片
        total = sum(len(v) for v in categories.values())
        videos.append({
            "vod_id": "summary",
            "vod_name": f"📊 资源汇总: 共{total}个源 / {len(categories)}个分类",
            "vod_pic": "",
            "vod_remarks": "点击下方分类浏览对应源",
        })
        # 分类卡片
        for cat, items in sorted(categories.items(), key=lambda x: -len(x[1])):
            icon = "🔞" if "成人" in cat or "伦理" in cat or "吃瓜" in cat else "📂"
            videos.append({
                "vod_id": f"cat:{cat}",
                "vod_name": f"{icon} {cat} ({len(items)}个)",
                "vod_pic": "",
                "vod_remarks": f"共{len(items)}个源",
            })
        return {
            "class": [{"type_id": "all", "type_name": "全部分类"}],
            "list": videos,
        }

    def categoryContent(self, tid, pg, filter, extend):
        if tid == "all":
            return self.homeContent(filter)
        categories = _scan_local_sources()
        items = categories.get(tid, [])
        videos = []
        videos.append({
            "vod_id": "back",
            "vod_name": f"← 返回分类列表",
            "vod_pic": "",
            "vod_remarks": f"当前分类: {tid} ({len(items)}个源)",
        })
        for item in items:
            size_kb = round(item['size'] / 1024, 1)
            videos.append({
                "vod_id": f"src:{item['filename']}",
                "vod_name": f"🎬 {item['name']}",
                "vod_pic": "",
                "vod_remarks": f"{item['category']} | {size_kb}KB",
            })
        return {
            "class": [{"type_id": tid, "type_name": tid}],
            "list": videos,
        }

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, (list, tuple)) else ids
        if vid == "back":
            return self.homeContent(False)
        if vid == "summary":
            categories = _scan_local_sources()
            total = sum(len(v) for v in categories.values())
            desc = f"📚 资源中心汇总\n\n"
            desc += f"总计: {total}个源 / {len(categories)}个分类\n\n"
            desc += "--- 分类列表 ---\n"
            for cat, items in sorted(categories.items(), key=lambda x: -len(x[1])):
                desc += f"\n[{cat}]: {len(items)}个源\n"
                for item in items[:5]:
                    desc += f"  • {item['name']}\n"
                if len(items) > 5:
                    desc += f"  ...等{len(items)}个\n"
            return {
                "list": [{
                    "vod_id": vid,
                    "vod_name": "📚 资源中心汇总",
                    "vod_pic": "",
                    "vod_content": desc,
                }]
            }
        if vid.startswith("cat:"):
            cat = vid[4:]
            categories = _scan_local_sources()
            items = categories.get(cat, [])
            desc = f"📂 分类: {cat}\n\n"
            desc += f"共{len(items)}个源\n\n"
            desc += "--- 源列表 ---\n"
            for item in items:
                size_kb = round(item['size'] / 1024, 1)
                desc += f"\n🎬 {item['name']}\n"
                desc += f"  文件: {item['filename']}\n"
                desc += f"  大小: {size_kb} KB\n"
                desc += f"  路径: {PY_DIR}/{item['filename']}\n"
            return {
                "list": [{
                    "vod_id": vid,
                    "vod_name": f"📂 {cat}",
                    "vod_pic": "",
                    "vod_content": desc,
                }]
            }
        if vid.startswith("src:"):
            filename = vid[4:]
            filepath = os.path.join(PY_DIR, filename)
            if os.path.exists(filepath):
                size_kb = round(os.path.getsize(filepath) / 1024, 1)
                match = re.match(r'\[(.+?)\](.+?)(🔞)?\.py$', filename)
                if match:
                    category = match.group(1)
                    name = match.group(2).strip()
                else:
                    category = "未分类"
                    name = filename.replace('.py', '')
                desc = f"🎬 源详情\n\n"
                desc += f"名称: {name}\n"
                desc += f"分类: {category}\n"
                desc += f"文件: {filename}\n"
                desc += f"大小: {size_kb} KB\n"
                desc += f"路径: {filepath}\n\n"
                desc += "💡 使用方法:\n"
                desc += "返回TVBox首页，在站点列表中找到对应名称的源即可播放。\n"
                desc += "所有源已自动加载到站点列表中。"
            else:
                desc = f"文件不存在: {filepath}"
            return {
                "list": [{
                    "vod_id": vid,
                    "vod_name": f"🎬 {name}",
                    "vod_pic": "",
                    "vod_content": desc,
                }]
            }
        return {"list": []}

    def playerContent(self, flag, id, vipFlags):
        return {"parse": 0, "url": "", "header": {}}

    def searchContent(self, key, quick, pg):
        categories = _scan_local_sources()
        videos = []
        for cat, items in categories.items():
            for item in items:
                if key.lower() in item['name'].lower() or key.lower() in item['filename'].lower():
                    size_kb = round(item['size'] / 1024, 1)
                    videos.append({
                        "vod_id": f"src:{item['filename']}",
                        "vod_name": f"🎬 {item['name']}",
                        "vod_pic": "",
                        "vod_remarks": f"{item['category']} | {size_kb}KB",
                    })
        return {"list": videos}

    def destroy(self):
        pass
