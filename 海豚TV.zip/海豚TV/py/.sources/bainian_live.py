#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
百年直播 — TVBox直播聚合Spider
- 从 api.vipmisss.com 获取直播平台和主播列表
- 支持m3u8/flv/mp4等直播格式
- 兼容TVBox Python运行环境（urllib实现，不依赖requests）
"""
import sys
import json
import base64
import ssl
import urllib.parse
import urllib.request
from urllib.parse import urljoin

try:
    from base.spider import Spider as BaseSpider
except ImportError:
    class BaseSpider:
        def init(self, extend=""): pass
        def homeContent(self, filter): pass
        def homeVideoContent(self): pass
        def categoryContent(self, tid, pg, filter, extend): pass
        def detailContent(self, ids): pass
        def searchContent(self, key, quick): pass
        def playerContent(self, flag, id, vipFlags): pass
        def localProxy(self, param): pass
        def isVideoFormat(self, url): pass
        def manualVideoCheck(self): pass
        def getName(self): pass


class Spider(BaseSpider):
    def __init__(self):
        self.domain = "http://api.vipmisss.com:81/xcdsw"
        self._ssl_context = None
        self._timeout = 10

    def init(self, extend=""):
        self._ssl_context = ssl.create_default_context()
        # 兼容ext参数传入自定义域名
        if isinstance(extend, str) and extend.strip():
            if extend.strip().startswith("http"):
                self.domain = extend.strip().rstrip("/")

    def getName(self):
        return "百年直播"

    def _http_get(self, url):
        """统一HTTP GET，兼容TVBox环境"""
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Referer": self.domain,
        }
        req = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw)
        except Exception:
            return None

    def homeContent(self, filter):
        url = f"{self.domain}/json.txt"
        json_data = self._http_get(url)
        if not json_data:
            return {"class": [], "list": []}
        classes = []
        for pt in json_data.get("pingtai", []):
            addr = pt.get("address", "")
            title = pt.get("title", "")
            if addr and title:
                classes.append({
                    "type_id": addr,
                    "type_name": title
                })
        return {"class": classes, "list": []}

    def homeVideoContent(self):
        return {"list": []}

    def categoryContent(self, tid, pg, filter, extend):
        url = f"{self.domain}/{tid}"
        json_data = self._http_get(url)
        if not json_data:
            return {"page": int(pg), "pagecount": 1, "limit": 999, "total": 0, "list": []}
        videos = []
        for zb in json_data.get("zhubo", []):
            addr = zb.get("address", "")
            if not addr:
                continue
            # 过滤rtmp（TVBox内置播放器不支持）
            if "rtmp" in addr.lower():
                continue
            img = zb.get("img", "")
            if img and not img.startswith("http"):
                img = urljoin(f"{self.domain}/", img)
            title = zb.get("title", "") or "未知主播"
            # vod_id用base64编码，保存标题/地址/封面
            vid = base64.b64encode(f"{title}|{addr}|{img}".encode("utf-8")).decode("ascii")
            videos.append({
                "vod_id": vid,
                "vod_name": title,
                "vod_pic": img,
                "vod_remarks": "直播中"
            })
        return {
            "page": int(pg),
            "pagecount": 1,
            "limit": 999,
            "total": len(videos),
            "list": videos
        }

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, (list, tuple)) else ids
        try:
            info = base64.b64decode(vid).decode("utf-8")
            parts = info.split("|")
            title = parts[0] if len(parts) > 0 else ""
            addr = parts[1] if len(parts) > 1 else ""
            img = parts[2] if len(parts) > 2 else ""
        except Exception:
            title = ""
            addr = vid
            img = ""
        return {
            "list": [{
                "vod_id": vid,
                "vod_name": title,
                "vod_pic": img,
                "vod_remarks": "直播",
                "vod_play_from": "直播源",
                "vod_play_url": f"第1集${addr}"
            }]
        }

    def searchContent(self, key, quick):
        return {"list": []}

    def playerContent(self, flag, id, vipFlags=None):
        # id就是直播地址，直接返回让播放器播放
        return {
            "parse": 0,
            "playUrl": "",
            "url": id,
            "header": {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        }

    def localProxy(self, param):
        return [200, "application/vnd.apple.mpegurl", b""]

    def isVideoFormat(self, url):
        if not url:
            return False
        url_lower = url.lower().split("?")[0]
        return any(url_lower.endswith(ext) for ext in [".m3u8", ".mp4", ".flv", ".ts", ".m4a"])

    def manualVideoCheck(self):
        return False
