#!/usr/bin/python
# coding=utf-8
import re, json
try:
    import requests
except ImportError:
    requests = None
from urllib.parse import quote
try:
    from base.spider import Spider as _BaseSpider
except ImportError:
    class _BaseSpider:
        pass

class Spider(_BaseSpider):
    def __init__(self):
        try:
            super().__init__()
        except Exception:
            pass
        self.name = "高清极速"
        self.host = "https://728.pyyyy12.icu"
        self.header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": self.host,
            "Accept-Language": "zh-CN,zh;q=0.9"
        }
        self.cookies = {"age_check": "1", "over18": "1"}

    def fix_url(self, url):
        if not url:
            return ""
        if url.startswith("//"):
            return "https:" + url
        if url.startswith("/"):
            return self.host + url
        return url

    def getName(self):
        return self.name

    def init(self, extend=""):
        pass

    def homeContent(self, filter):
        r = requests.get(f"{self.host}/sp/index.php/vod/type/id/1.html", headers=self.header, cookies=self.cookies, timeout=10)
        r.raise_for_status()
        html = r.text
        classes = []
        seen = set()
        for m in re.finditer(r'<a[^>]+href="/sp/index\.php/vod/type/id/(\d+)\.html"[^>]*>([^<]+)</a>', html):
            tid, name = m.group(1), m.group(2).strip()
            if tid not in seen and name not in ["首页", "登录", "注册", "会员", "充值", "APP", "下载", "搜索", "排行", "最新", "热门", "专题", "资讯", "留言", "求片"]:
                seen.add(tid)
                classes.append({"type_name": name, "type_id": tid})
        videos = self._extract_list(html)
        return {"class": classes, "list": videos}

    def homeVideoContent(self):
        r = requests.get(f"{self.host}/sp/index.php/vod/type/id/1.html", headers=self.header, cookies=self.cookies, timeout=10)
        return {"list": self._extract_list(r.text)}

    def categoryContent(self, tid, pg, filter, extend):
        url = f"{self.host}/sp/index.php/vod/type/id/{tid}/page/{pg}.html" if int(pg) > 1 else f"{self.host}/sp/index.php/vod/type/id/{tid}.html"
        r = requests.get(url, headers=self.header, cookies=self.cookies, timeout=10)
        videos = self._extract_list(r.text)
        pagecount = 999
        total = 9999
        if len(videos) < 20 and int(pg) > 1:
            pagecount = int(pg)
            total = (int(pg) - 1) * 20 + len(videos)
        return {"list": videos, "page": int(pg), "pagecount": pagecount, "limit": 20, "total": total}

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, list) else ids
        url = f"{self.host}/sp/index.php/vod/detail/id/{vid}.html"
        r = requests.get(url, headers=self.header, cookies=self.cookies, timeout=10)
        html = r.text
        title = ""
        pic = ""
        desc = ""
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        if m:
            title = m.group(1).strip()
        m = re.search(r'<img[^>]+class="img-responsive"[^>]+src="([^"]+)"', html)
        if m:
            pic = self.fix_url(m.group(1))
        m = re.search(r'<p[^>]*class="desc[^"]*"[^>]*>([\s\S]*?)</p>', html)
        if m:
            desc = re.sub(r'<[^>]+>', '', m.group(1)).strip()
        play_from = []
        play_url = []
        current_from = ""
        current_urls = []
        for m in re.finditer(r'<h3[^>]*class="stui-pannel__title"[^>]*>([\s\S]*?)</h3>', html):
            from_name = re.sub(r'<[^>]+>', '', m.group(1)).strip()
            if from_name and ("播放" in from_name or "线路" in from_name or "源" in from_name):
                current_from = from_name.replace("播放", "").strip()
        for m in re.finditer(r'<a[^>]+href="(/sp/index\.php/vod/play/id/\d+/sid/\d+/nid/\d+\.html)"[^>]*>([^<]+)</a>', html):
            href, ep_name = m.group(1), m.group(2).strip()
            current_urls.append(f"{ep_name}${self.fix_url(href)}")
        if current_urls:
            play_from.append(current_from if current_from else "线路1")
            play_url.append("#".join(current_urls))
        if not current_urls:
            m = re.search(r'href="(/sp/index\.php/vod/play/id/\d+/sid/\d+/nid/\d+\.html)"', html)
            if m:
                play_from.append("线路1")
                play_url.append(f"播放${self.fix_url(m.group(1))}")
        vod_play_from = "$$$".join(play_from) if play_from else ""
        vod_play_url = "$$$".join(play_url) if play_url else ""
        return {
            "list": [{
                "vod_id": vid,
                "vod_name": title,
                "vod_pic": pic,
                "vod_content": desc,
                "vod_play_from": vod_play_from,
                "vod_play_url": vod_play_url
            }]
        }

    def searchContent(self, key, quick, pg=1):
        url = f"{self.host}/sp/index.php/vod/search.html?wd={quote(key)}"
        if int(pg) > 1:
            url = f"{self.host}/sp/index.php/vod/search.html?wd={quote(key)}&page={pg}"
        r = requests.get(url, headers=self.header, cookies=self.cookies, timeout=10)
        videos = self._extract_list(r.text)
        return {"list": videos, "page": int(pg), "pagecount": 999, "limit": 20, "total": 9999}

    def playerContent(self, flag, id, vipFlags):
        if ".m3u8" in id or ".mp4" in id:
            return {"parse": 0, "url": id, "header": self.header}
        url = id if id.startswith("http") else self.fix_url(id)
        if "vod/play" not in url:
            return {"parse": 1, "url": url, "header": self.header}
        r = requests.get(url, headers=self.header, cookies=self.cookies, timeout=10)
        html = r.text
        m = re.search(r'var player_aaaa=(\{[^;]+\});', html)
        if m:
            try:
                player_data = json.loads(m.group(1))
                m3u8 = player_data.get("url", "")
                if m3u8:
                    return {"parse": 0, "url": m3u8, "header": self.header}
            except Exception:
                pass
        m = re.search(r'var now=["\']([^"\']+\.m3u8[^"\']*)["\']', html)
        if m:
            return {"parse": 0, "url": m.group(1), "header": self.header}
        m = re.search(r'var url=["\']([^"\']+\.m3u8[^"\']*)["\']', html)
        if m:
            return {"parse": 0, "url": m.group(1), "header": self.header}
        m = re.search(r'<source[^>]+src=["\']([^"\']+\.m3u8[^"\']*)["\']', html)
        if m:
            return {"parse": 0, "url": m.group(1), "header": self.header}
        m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html)
        if m:
            iframe_url = self.fix_url(m.group(1))
            return {"parse": 1, "url": iframe_url, "header": self.header}
        return {"parse": 1, "url": url, "header": self.header}

    def localProxy(self, param):
        pass

    def _extract_list(self, html):
        videos = []
        seen = set()
        for m in re.finditer(r'<div class="stui-vodlist__box">([\s\S]*?)</div>\s*</li>', html):
            item = m.group(1)
            m2 = re.search(r'href="/sp/index\.php/vod/detail/id/(\d+)\.html"[^>]*title="([^"]+)"', item)
            if not m2:
                continue
            vid, title = m2.group(1), m2.group(2).strip()
            if vid in seen:
                continue
            seen.add(vid)
            pic = ""
            m3 = re.search(r'data-original="([^"]+)"', item)
            if m3:
                pic = m3.group(1)
            if not pic:
                m3 = re.search(r'src="([^"]+)"', item)
                if m3:
                    pic = m3.group(1)
            pic = self.fix_url(pic)
            remark = ""
            m4 = re.search(r'<span class="pic-text[^"]*">([^<]+)</span>', item)
            if m4:
                remark = m4.group(1).strip()
            videos.append({"vod_id": vid, "vod_name": title, "vod_pic": pic, "vod_remarks": remark})
        return videos
