#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 猛男影院 (oul.mnyy7.boats/mnyy) — MACCMS(stui模板) spider
# 兼容 WebHomeTV / PickTV(PeekPro) / OK影视 / 影视仓 四壳（同 compat/spider_template.py 写法）
#
# 站点要点(2026-08-27 实测)：
#  - 全站可直连，无需 jina。老入口 /mnyy/ 会 302 到 /cn/home/web/
#  - 分类页: /cn/home/web/index.php/vod/type/id/{tid}/page/{pg}.html，tid=20..32，最多743页
#  - 列表项: a.stui-vodlist__thumb lazyload[href=/vod/play/id/{id}/sid/1/nid/1.html]
#            title=标题 data-original=封面图; 标题重复出现 h4.stui-vodlist__title>a
#  - 搜索: 必须 POST wd 到 /index.php/vod/search.html（GET ?wd= 同样200但返回首页无效），
#          一次返回全量结果、无分页条 → 固定返回 pagecount=1
#  - 播放页: <script>var player_data={...,"url":"https://....m3u8", from:"ckplayer"}</script> 明文直链
#            单集，nid/sid 恒为 1；播放页无封面
import sys
import re
import json

try:
    import requests as _requests
    _HAS_REQ = True
except ImportError:
    _HAS_REQ = False
    import urllib.request
    import urllib.parse as urlparse

UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
SITE = "https://oul.mnyy7.boats"
BASE = SITE + "/cn/home/web"
SITE_NAME = "猛男影院"

CLASS_LIST = [
    ("20", "国产精品"), ("21", "精品三级"), ("22", "主播大秀"),
    ("23", "抖阴视频"), ("24", "女神学生"), ("25", "美熟少妇"),
    ("26", "娇妻素人"), ("27", "空姐模特"), ("28", "国产乱伦"),
    ("29", "自慰群交"), ("30", "野合车震"), ("31", "职场同事"),
    ("32", "网红流出"),
]


class _Http:
    def __init__(self):
        self.session = _requests.Session() if _HAS_REQ else None

    def get(self, url, headers=None, timeout=20):
        hdrs = {"User-Agent": UA, "Referer": BASE + "/"}
        if headers:
            hdrs.update(headers)
        if _HAS_REQ:
            return self.session.get(url, headers=hdrs, timeout=timeout, verify=False).text
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', 'replace')

    def post(self, url, data=None, headers=None, timeout=20):
        hdrs = {"User-Agent": UA, "Referer": BASE + "/"}
        if headers:
            hdrs.update(headers)
        if _HAS_REQ:
            return self.session.post(url, data=data, headers=hdrs, timeout=timeout,
                                     verify=False).text
        body = urlparse.urlencode(data).encode() if isinstance(data, dict) else (data or b"")
        req = urllib.request.Request(url, data=body, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', 'replace')


def _int_pg(pg):
    try:
        p = int(str(pg))
        return p if p > 0 else 1
    except Exception:
        return 1


class Spider:
    name = SITE_NAME
    version = "1.0.0"

    def __init__(self):
        self.http = _Http()
        self.s = self.http.session
        self.session = self.http.session
        self.sess = self.http.session
        self.extend = ""

    def getDependence(self):
        return []

    def init(self, extend=""):
        if not isinstance(extend, str):
            extend = ""
        self.extend = extend
        self.http = _Http()
        self.s = self.http.session
        self.session = self.http.session
        self.sess = self.http.session

    def destroy(self):
        pass

    # ── 解析 ──
    @staticmethod
    def _dedup(seq):
        seen, out = set(), []
        for x in seq:
            if x not in seen:
                seen.add(x)
                out.append(x)
        return out

    def _parse_list(self, html):
        """stui-vodlist 卡片: <a class="stui-vodlist__thumb lazyload" href=.. title=.. data-original=img>"""
        vlist = []
        pat = re.compile(
            r'<a\s+class="stui-vodlist__thumb[^"]*"\s+href="([^"]+)"\s+title="([^"]*)"\s+'
            r'data-original="([^"]*)"', re.S)
        for href, title, pic in self._dedup(pat.findall(html)):
            m = re.search(r'/vod/play/id/(\d+)/sid/1/nid/1\.html', href)
            if not m:
                continue
            vid = m.group(1)
            if not pic:
                continue
            t = title.strip()
            # 参考同类影院源惯例：超长堆砌标题截断展示
            if len(t) > 36:
                t = t[:36] + "…"
            vlist.append({
                "vod_id": vid,
                "vod_name": t,
                "vod_pic": pic,
                "vod_remarks": "",
            })
        return vlist

    @staticmethod
    def _pagecount(html):
        m = re.findall(r'/page/(\d+)\.html', html or "")
        return max(int(x) for x in m) if m else 1

    # ── 首页 ──
    def homeContent(self, filter=None):
        classes = [{"type_id": tid, "type_name": tn} for tid, tn in CLASS_LIST]
        try:
            vlist = self._parse_list(self.http.get(BASE + "/"))
        except Exception:
            vlist = []
        return {"class": classes, "filters": {}, "list": vlist}

    def homeVideoContent(self):
        try:
            return {"list": self._parse_list(self.http.get(BASE + "/"))}
        except Exception:
            return {"list": []}

    # ── 分类 ──
    def categoryContent(self, tid, pg=1, filter=None, extend=None):
        pg = _int_pg(pg)
        tid = str(tid)
        if tid not in dict(CLASS_LIST):
            tid = "20"
        url = "%s/index.php/vod/type/id/%s/page/%d.html" % (BASE, tid, pg)
        try:
            html = self.http.get(url)
            vlist = self._parse_list(html)
            last = self._pagecount(html)
        except Exception:
            vlist, last = [], 1
        total = last * 36
        return {"list": vlist, "page": pg, "pagecount": last, "limit": 36, "total": total}

    # ── 详情 ──
    def detailContent(self, ids):
        vid = str(ids[0]) if isinstance(ids, (list, tuple)) else str(ids)
        m = re.search(r'(\d+)', vid)
        vid = m.group(1) if m else ""
        play_url, name = "", ""
        if vid:
            try:
                html = self.http.get("%s/index.php/vod/play/id/%s/sid/1/nid/1.html" % (BASE, vid))
                name, play_url = self._parse_player(html)
            except Exception:
                pass
        if not play_url:
            return {"list": []}
        vod = {
            "vod_id": vid,
            "vod_name": name or ("视频" + vid),
            "vod_pic": "",
            "type_name": "",
            "vod_year": "",
            "vod_area": "",
            "vod_actor": "",
            "vod_director": "",
            "vod_content": "",
            "vod_remarks": "",
            "vod_play_from": "正片",
            "vod_play_url": "正片$" + play_url,
        }
        return {"list": [vod]}

    @staticmethod
    def _parse_player(html):
        """取 var player_data={...} 里的 url 与页面标题"""
        url = name = ""
        m = re.search(r'var\s+player_data\s*=\s*(\{.*?\})\s*;?\s*</script>', html, re.S)
        if m:
            try:
                d = json.loads(m.group(1))
                url = (d.get("url") or "").replace("\\/", "/")
            except Exception:
                mm = re.search(r'"url":"([^"]+)"', m.group(1))
                if mm:
                    url = mm.group(1).replace("\\/", "/")
        t = re.search(r'<h3 class="title">([^<]+)</h3>', html)
        if t:
            name = t.group(1).strip()
        return name, url

    # ── 搜索 ──
    def searchContent(self, key, quick=False, pg="1"):
        pg = _int_pg(pg)
        if pg > 1:
            return {"list": []}          # 站点搜索一次给全量、无分页
        try:
            html = self.http.post(BASE + "/index.php/vod/search.html",
                                  data={"wd": str(key)})
            vlist = self._parse_list(html)
        except Exception:
            vlist = []
        return {"list": vlist, "page": 1, "pagecount": 1, "limit": 99, "total": len(vlist)}

    # ── 播放 ──
    def playerContent(self, flag, ids, vipFlags=None):
        url = ids[0] if isinstance(ids, (list, tuple)) else str(ids)
        url = str(url).replace("\\/", "/")
        return {
            "parse": 0,
            "url": url,
            "header": {"User-Agent": UA, "Referer": SITE + "/"},
            "format": "application/x-mpegURL",
        }

    # ── 壳契约方法 ──
    def localProxy(self, param):
        return [200, "text/plain", "", {}]

    def manualVideoCheck(self):
        return False

    def isVideoFormat(self, url):
        u = str(url).lower()
        return any(u.endswith(ext) for ext in
                   (".m3u8", ".mp4", ".flv", ".ts", ".mkv", ".m4s"))

    def action(self, action):
        return json.dumps({"code": 0, "msg": "ok"}, ensure_ascii=False)

    def getName(self):
        return self.name


# ── 本地自测：模拟壳的调用链 ──
if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    import urllib3
    urllib3.disable_warnings()

    sp = Spider()
    sp.init("")
    print("== home ==")
    h = sp.homeContent(True)
    print("classes:", [(c["type_id"], c["type_name"]) for c in h["class"]])
    print("home list:", len(h["list"]), h["list"][0] if h["list"] else "-")
    hv = sp.homeVideoContent()
    print("homeVideo:", len(hv["list"]))
    print("== category 20/p1 ==")
    c = sp.categoryContent("20", "1", False, {})
    print("n=%d page=%s pagecount=%s first=%s" %
          (len(c["list"]), c["page"], c["pagecount"],
           c["list"][0]["vod_name"][:20] if c["list"] else "-"))
    print("== category 32/p743 边界 ==")
    c2 = sp.categoryContent("32", "743", False, {})
    print("n=%d pagecount=%s" % (len(c2["list"]), c2["pagecount"]))
    if c["list"]:
        d = sp.detailContent([c["list"][0]["vod_id"]])
        print("== detail ==")
        if d["list"]:
            v = d["list"][0]
            print(v["vod_name"][:24], "|", v["vod_play_url"][:90])
            f, i = v["vod_play_from"], v["vod_play_url"].split("$")[1]
            p = sp.playerContent(f, i)
            print("player parse=%s url=%s..." % (p["parse"], p["url"][:60]))
    print("== search ==")
    sres = sp.searchContent("素人")
    print("n=%d" % len(sres["list"]))
    for it in sres["list"][:3]:
        print("  ", it["vod_name"][:26])
