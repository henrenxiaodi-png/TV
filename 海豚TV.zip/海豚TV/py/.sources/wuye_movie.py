# -*- coding: utf-8 -*-
"""
午夜电影 - 18㊙️专属资源中心
功能：分类展示所有18㊙️源、配置中心加密入口、在线本地开关、站点检测
"""
import os
import json
import re

import datetime

def _check_access_time():
    """检查是否在允许访问时间内（20:00-05:00）"""
    now = datetime.datetime.now()
    hour = now.hour
    # 20:00-23:59 或 00:00-05:00 允许访问
    if hour >= 20 or hour < 5:
        return True, ""
    else:
        return False, f"当前时间 {now.strftime('%H:%M')}，午夜电影仅在 20:00-05:00 开放访问"


PY_DIR = "/storage/emulated/0/海豚TV/py"
CONFIG_DIR = "/storage/emulated/0/海豚TV"
ENCRYPTED_CONFIG_FILE = os.path.join(CONFIG_DIR, ".wuye_encrypted.json")
ONLINE_LOCAL_CONFIG = os.path.join(CONFIG_DIR, ".wuye_online_local.json")
SITE_CHECK_RESULT = os.path.join(CONFIG_DIR, ".wuye_check_result.json")

# 18㊙️源的关键词
WUYE_KEYWORDS = ["18㊙️", "18🈲", "成人", "吃瓜", "伦理", "午夜", "supjav", "javdb", "mengnan", "qisegu", "gaoqing", "gaokao", "weimei", "bainian"]

# 文件名 -> 中文名映射
WUYE_NAME_MAP = {
    "mengnan": "猛男影院",
    "qisegu": "七色谷",
    "gaoqing": "高清极速",
    "gaokao": "高考模拟",
    "weimei": "唯美精品",
    "bainian_live": "百年直播",
    "javdb_aowu": "JAVDB",
    "supjav": "SupJav",
}


def _is_wuye_source(filename, name=""):
    """判断是否为午夜电影源"""
    text = filename + name
    for kw in WUYE_KEYWORDS:
        if kw.lower() in text.lower():
            return True
    return False

def _scan_wuye_sources():
    """扫描本地18㊙️源，按分类整理（包括.sources隐藏目录）"""
    categories = {}
    scan_dirs = [PY_DIR, os.path.join(PY_DIR, ".sources")]
    for scan_dir in scan_dirs:
        if not os.path.exists(scan_dir):
            continue
        for filename in os.listdir(scan_dir):
            if not filename.endswith('.py'):
                continue
        skip_list = ['list_nav.py', 'list.py', 'list_with_remote.py',
                     'password_center.py', 'site_checker.py', 'smart_loader.py',
                     'resource_center.py', 'wuye_movie.py', 'aowu_config.py', '__init__.py']
        if filename in skip_list:
            continue
        match = re.match(r'\[(.+?)\](.+?)(🔞)?\.py$', filename)
        if match:
            category = match.group(1)
            name = match.group(2).strip()
        else:
            category = "午夜电影"
            base_name = filename.replace('.py', '')
            name = WUYE_NAME_MAP.get(base_name, base_name)
        if not _is_wuye_source(filename, name):
            continue
        # 打上18㊙️标签
        if not name.startswith("18㊙️"):
            name = "18㊙️" + name
        if category not in categories:
            categories[category] = []
        categories[category].append({
            'filename': filename,
            'name': '🎬 ' + name,
            'category': category,
            'size': os.path.getsize(os.path.join(PY_DIR, filename)),
        })
    return categories

def _load_encrypted_config():
    """加载加密配置"""
    try:
        if os.path.exists(ENCRYPTED_CONFIG_FILE):
            with open(ENCRYPTED_CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return {"encrypted": False, "password": "", "sources": []}

def _save_encrypted_config(config):
    """保存加密配置"""
    try:
        with open(ENCRYPTED_CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False

def _load_online_local_config():
    """加载在线本地开关配置"""
    try:
        if os.path.exists(ONLINE_LOCAL_CONFIG):
            with open(ONLINE_LOCAL_CONFIG, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return {"mode": "both", "online_url": "", "local_enabled": True, "online_enabled": True}

class Spider:
    """午夜电影 - 18㊙️专属资源中心"""
    filterable = False

    def __init__(self):
        self.ext = ""

    def init(self, extend=""):
        self.ext = extend

    def getName(self):
        return "🌙 午夜电影"

    def homeContent(self, filter):
        allowed, msg = _check_access_time()
        if not allowed:
            return {
                "class": [{"type_id": "locked", "type_name": "午夜电影"}],
                "list": [{
                    "vod_id": "time_locked",
                    "vod_name": "🌙 午夜电影 - 非开放时间",
                    "vod_pic": "",
                    "vod_remarks": msg,
                }],
            }
        categories = _scan_wuye_sources()
        total = sum(len(v) for v in categories.values())
        videos = []
        # 功能入口卡片
        videos.append({
            "vod_id": "func_encrypt",
            "vod_name": "🔐 配置中心加密",
            "vod_pic": "",
            "vod_remarks": "加密保护午夜电影配置",
        })
        videos.append({
            "vod_id": "func_online_local",
            "vod_name": "🔄 在线/本地开关",
            "vod_pic": "",
            "vod_remarks": "切换在线/本地/混合模式",
        })
        videos.append({
            "vod_id": "func_check",
            "vod_name": "🔍 站点检测",
            "vod_pic": "",
            "vod_remarks": "检测所有午夜电影源可用性",
        })
        videos.append({
            "vod_id": "summary",
            "vod_name": f"📊 资源汇总: {total}个午夜源 / {len(categories)}个分类",
            "vod_pic": "",
            "vod_remarks": "点击下方分类浏览",
        })
        # 分类卡片
        for cat, items in sorted(categories.items(), key=lambda x: -len(x[1])):
            videos.append({
                "vod_id": f"cat:{cat}",
                "vod_name": f"🌙 {cat} ({len(items)}个)",
                "vod_pic": "",
                "vod_remarks": f"共{len(items)}个午夜电影源",
            })
        return {
            "class": [{"type_id": "all", "type_name": "午夜电影"}],
            "list": videos,
        }

    def categoryContent(self, tid, pg, filter, extend):
        allowed, msg = _check_access_time()
        if not allowed:
            return {
                "class": [{"type_id": tid, "type_name": "午夜电影"}],
                "list": [{
                    "vod_id": "time_locked",
                    "vod_name": "🌙 午夜电影 - 非开放时间",
                    "vod_pic": "",
                    "vod_remarks": msg,
                }],
            }
        if tid == "all":
            return self.homeContent(filter)
        categories = _scan_wuye_sources()
        items = categories.get(tid, [])
        videos = []
        videos.append({
            "vod_id": "back",
            "vod_name": "← 返回午夜电影首页",
            "vod_pic": "",
            "vod_remarks": f"当前分类: {tid} ({len(items)}个源)",
        })
        for item in items:
            size_kb = round(item['size'] / 1024, 1)
            videos.append({
                "vod_id": f"src:{item['filename']}",
                "vod_name": item['name'],
                "vod_pic": "",
                "vod_remarks": f"🌙午夜电影 | {item['category']} | {size_kb}KB",
            })
        return {
            "class": [{"type_id": tid, "type_name": tid}],
            "list": videos,
        }

    def detailContent(self, ids):
        allowed, msg = _check_access_time()
        if not allowed:
            return {"list": [{"vod_id": "time_locked", "vod_name": "🌙 午夜电影 - 非开放时间", "vod_pic": "", "vod_content": msg}]}
        vid = ids[0] if isinstance(ids, (list, tuple)) else ids
        if vid == "back":
            return self.homeContent(False)
        if vid == "func_encrypt":
            config = _load_encrypted_config()
            desc = "🔐 配置中心加密\n\n"
            desc += f"加密状态: {'已加密' if config.get('encrypted') else '未加密'}\n"
            desc += f"密码: {'已设置' if config.get('password') else '未设置'}\n\n"
            desc += "💡 使用方法:\n"
            desc += "1. 在搜索框输入: set:密码（设置加密密码）\n"
            desc += "2. 在搜索框输入: lock（锁定配置）\n"
            desc += "3. 在搜索框输入: unlock:密码（解锁配置）\n"
            desc += f"\n配置文件: {ENCRYPTED_CONFIG_FILE}"
            return {"list": [{"vod_id": vid, "vod_name": "🔐 配置中心加密", "vod_pic": "", "vod_content": desc}]}
        if vid == "func_online_local":
            config = _load_online_local_config()
            mode_map = {"local": "仅本地", "online": "仅在线", "both": "本地+在线"}
            desc = "🔄 在线/本地开关\n\n"
            desc += f"当前模式: {mode_map.get(config.get('mode', 'both'), '本地+在线')}\n"
            desc += f"本地源: {'启用' if config.get('local_enabled', True) else '禁用'}\n"
            desc += f"在线源: {'启用' if config.get('online_enabled', True) else '禁用'}\n"
            desc += f"在线地址: {config.get('online_url', '未设置')}\n\n"
            desc += "💡 使用方法:\n"
            desc += "1. 搜索框输入: mode:local（仅本地）\n"
            desc += "2. 搜索框输入: mode:online（仅在线）\n"
            desc += "3. 搜索框输入: mode:both（本地+在线）\n"
            desc += "4. 搜索框输入: url:在线地址（设置在线地址）\n"
            desc += f"\n配置文件: {ONLINE_LOCAL_CONFIG}"
            return {"list": [{"vod_id": vid, "vod_name": "🔄 在线/本地开关", "vod_pic": "", "vod_content": desc}]}
        if vid == "func_check":
            desc = "🔍 站点检测\n\n"
            desc += "检测所有午夜电影源的可用性\n\n"
            desc += "💡 使用方法:\n"
            desc += "1. 搜索框输入: check（开始检测）\n"
            desc += "2. 搜索框输入: check:文件名（检测单个源）\n"
            desc += "3. 搜索框输入: result（查看检测结果）\n\n"
            desc += f"检测结果文件: {SITE_CHECK_RESULT}\n"
            desc += f"源目录: {PY_DIR}"
            return {"list": [{"vod_id": vid, "vod_name": "🔍 站点检测", "vod_pic": "", "vod_content": desc}]}
        if vid == "summary":
            categories = _scan_wuye_sources()
            total = sum(len(v) for v in categories.values())
            desc = "🌙 午夜电影资源汇总\n\n"
            desc += f"总计: {total}个午夜源 / {len(categories)}个分类\n\n"
            desc += "--- 分类列表 ---\n"
            for cat, items in sorted(categories.items(), key=lambda x: -len(x[1])):
                desc += f"\n🌙 {cat}: {len(items)}个源\n"
                for item in items[:5]:
                    desc += f"  • {item['name']}\n"
                if len(items) > 5:
                    desc += f"  ...等{len(items)}个\n"
            return {"list": [{"vod_id": vid, "vod_name": "🌙 午夜电影汇总", "vod_pic": "", "vod_content": desc}]}
        if vid.startswith("cat:"):
            cat = vid[4:]
            categories = _scan_wuye_sources()
            items = categories.get(cat, [])
            desc = f"🌙 分类: {cat}\n\n"
            desc += f"共{len(items)}个午夜电影源\n\n"
            desc += "--- 源列表 ---\n"
            for item in items:
                size_kb = round(item['size'] / 1024, 1)
                desc += f"\n{item['name']}\n"
                desc += f"  文件: {item['filename']}\n"
                desc += f"  大小: {size_kb} KB\n"
                desc += f"  路径: {PY_DIR}/{item['filename']}\n"
            return {"list": [{"vod_id": vid, "vod_name": f"🌙 {cat}", "vod_pic": "", "vod_content": desc}]}
        if vid.startswith("src:"):
            filename = vid[4:]
            filepath = os.path.join(PY_DIR, filename)
            if os.path.exists(filepath):
                size_kb = round(os.path.getsize(filepath) / 1024, 1)
                match = re.match(r'\[(.+?)\](.+?)(🔞)?\.py$', filename)
                if match:
                    category = match.group(1)
                    name = match.group(2).strip()
                else:
                    category = "午夜电影"
                    name = filename.replace('.py', '')
                desc = "🌙 午夜电影源详情\n\n"
                desc += f"名称: 🎬 {name}\n"
                desc += f"分类: 🌙 {category}\n"
                desc += f"标签: 18㊙️ 午夜电影\n"
                desc += f"文件: {filename}\n"
                desc += f"大小: {size_kb} KB\n"
                desc += f"路径: {filepath}\n\n"
                desc += "💡 使用方法:\n"
                desc += "返回TVBox首页，在站点列表中找到对应名称的源即可播放。\n"
                desc += "所有午夜电影源已自动加载到站点列表中。"
            else:
                desc = f"文件不存在: {filepath}"
            return {"list": [{"vod_id": vid, "vod_name": f"🎬 {name}", "vod_pic": "", "vod_content": desc}]}
        return {"list": []}

    def playerContent(self, flag, id, vipFlags):
        return {"parse": 0, "url": "", "header": {}}

    def searchContent(self, key, quick, pg):
        allowed, msg = _check_access_time()
        if not allowed:
            return {"list": [{"vod_id": "time_locked", "vod_name": "🌙 午夜电影 - 非开放时间", "vod_remarks": msg}]}
        # 处理功能命令
        if key.startswith("set:"):
            pwd = key[4:]
            config = _load_encrypted_config()
            config['password'] = pwd
            config['encrypted'] = True
            _save_encrypted_config(config)
            return {"list": [{"vod_id": "ok", "vod_name": "✅ 加密密码已设置", "vod_remarks": f"密码: {pwd}"}]}
        if key == "lock":
            config = _load_encrypted_config()
            config['encrypted'] = True
            _save_encrypted_config(config)
            return {"list": [{"vod_id": "ok", "vod_name": "🔒 配置已锁定", "vod_remarks": "需要密码解锁"}]}
        if key.startswith("unlock:"):
            pwd = key[7:]
            config = _load_encrypted_config()
            if config.get('password') == pwd:
                config['encrypted'] = False
                _save_encrypted_config(config)
                return {"list": [{"vod_id": "ok", "vod_name": "🔓 配置已解锁", "vod_remarks": "可以正常访问"}]}
            else:
                return {"list": [{"vod_id": "err", "vod_name": "❌ 密码错误", "vod_remarks": "请重试"}]}
        if key.startswith("mode:"):
            mode = key[5:]
            config = _load_online_local_config()
            config['mode'] = mode
            if mode == "local":
                config['local_enabled'] = True
                config['online_enabled'] = False
            elif mode == "online":
                config['local_enabled'] = False
                config['online_enabled'] = True
            else:
                config['local_enabled'] = True
                config['online_enabled'] = True
            with open(ONLINE_LOCAL_CONFIG, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            mode_map = {"local": "仅本地", "online": "仅在线", "both": "本地+在线"}
            return {"list": [{"vod_id": "ok", "vod_name": f"✅ 模式已切换为{mode_map.get(mode, mode)}", "vod_remarks": "刷新配置生效"}]}
        if key.startswith("url:"):
            url = key[4:]
            config = _load_online_local_config()
            config['online_url'] = url
            with open(ONLINE_LOCAL_CONFIG, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            return {"list": [{"vod_id": "ok", "vod_name": "✅ 在线地址已设置", "vod_remarks": url}]}
        if key == "check" or key.startswith("check:") or key == "result":
            return {"list": [{"vod_id": "check", "vod_name": "🔍 站点检测", "vod_remarks": "检测功能请使用智能加载管理器"}]}
        # 普通搜索
        categories = _scan_wuye_sources()
        videos = []
        for cat, items in categories.items():
            for item in items:
                if key.lower() in item['name'].lower() or key.lower() in item['filename'].lower():
                    size_kb = round(item['size'] / 1024, 1)
                    videos.append({
                        "vod_id": f"src:{item['filename']}",
                        "vod_name": item['name'],
                        "vod_pic": "",
                        "vod_remarks": f"🌙午夜电影 | {item['category']} | {size_kb}KB",
                    })
        return {"list": videos}

    def destroy(self):
        pass
