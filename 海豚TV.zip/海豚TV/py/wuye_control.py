#!/usr/bin/python
# coding=utf-8
"""
午夜电影控制 - 设置访问密码和开放时间
"""
import os
import json
import time

CONFIG_FILE = "/storage/emulated/0/海豚TV/py/wuye_config.json"

try:
    from base.spider import Spider as _BaseSpider
except ImportError:
    class _BaseSpider:
        pass

class Spider(_BaseSpider):
    def __init__(self):
        try:
            super().__init__()
        except Exception:
            pass
        self.name = "🔒 午夜电影控制"
    
    def getName(self):
        return self.name
    
    def init(self, extend=""):
        pass
    
    def _load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {"password": "", "start_hour": 20, "end_hour": 5, "enabled": False}
    
    def _save_config(self, config):
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def homeContent(self, filter):
        config = self._load_config()
        videos = []
        videos.append({
            "vod_id": "status",
            "vod_name": f"📊 当前状态: {'已启用' if config.get('enabled') else '未启用'}",
            "vod_pic": "",
            "vod_remarks": f"密码: {'已设置' if config.get('password') else '未设置'} | 开放时间: {config.get('start_hour', 20)}:00 - {config.get('end_hour', 5)}:00",
        })
        videos.append({
            "vod_id": "enable",
            "vod_name": "🔓 启用/关闭访问控制",
            "vod_pic": "",
            "vod_remarks": "点击切换",
        })
        videos.append({
            "vod_id": "set_password",
            "vod_name": "🔑 设置访问密码",
            "vod_pic": "",
            "vod_remarks": f"当前: {'已设置' if config.get('password') else '未设置'}",
        })
        videos.append({
            "vod_id": "clear_password",
            "vod_name": "🗑️ 清除密码",
            "vod_pic": "",
            "vod_remarks": "点击清除密码",
        })
        videos.append({
            "vod_id": "set_time_20_5",
            "vod_name": "⏰ 设置开放时间 20:00-05:00",
            "vod_pic": "",
            "vod_remarks": "默认时间",
        })
        videos.append({
            "vod_id": "set_time_22_6",
            "vod_name": "⏰ 设置开放时间 22:00-06:00",
            "vod_pic": "",
            "vod_remarks": "晚睡时间",
        })
        videos.append({
            "vod_id": "set_time_0_24",
            "vod_name": "⏰ 全天开放",
            "vod_pic": "",
            "vod_remarks": "不限制时间",
        })
        videos.append({
            "vod_id": "test",
            "vod_name": "🧪 测试当前是否可访问",
            "vod_pic": "",
            "vod_remarks": "点击测试",
        })
        return {"class": [], "list": videos}
    
    def categoryContent(self, tid, pg, filter, extend):
        config = self._load_config()
        msg = ""
        if tid == "enable":
            config['enabled'] = not config.get('enabled', False)
            self._save_config(config)
            msg = f"✅ 访问控制已{'启用' if config['enabled'] else '关闭'}"
        elif tid == "set_password":
            # 简单设置：默认密码1234
            config['password'] = "1234"
            self._save_config(config)
            msg = "✅ 密码已设置为: 1234"
        elif tid == "clear_password":
            config['password'] = ""
            self._save_config(config)
            msg = "✅ 密码已清除"
        elif tid == "set_time_20_5":
            config['start_hour'] = 20
            config['end_hour'] = 5
            self._save_config(config)
            msg = "✅ 开放时间已设置为: 20:00-05:00"
        elif tid == "set_time_22_6":
            config['start_hour'] = 22
            config['end_hour'] = 6
            self._save_config(config)
            msg = "✅ 开放时间已设置为: 22:00-06:00"
        elif tid == "set_time_0_24":
            config['start_hour'] = 0
            config['end_hour'] = 24
            self._save_config(config)
            msg = "✅ 已设置为全天开放"
        elif tid == "test":
            now = time.localtime()
            hour = now.tm_hour
            start = config.get('start_hour', 20)
            end = config.get('end_hour', 5)
            if not config.get('enabled'):
                msg = "✅ 访问控制未启用，可随时访问"
            elif start <= end:
                if start <= hour < end:
                    msg = f"✅ 当前时间 {hour}:00 在开放时间内 ({start}:00-{end}:00)"
                else:
                    msg = f"❌ 当前时间 {hour}:00 不在开放时间内 ({start}:00-{end}:00)"
            else:
                if hour >= start or hour < end:
                    msg = f"✅ 当前时间 {hour}:00 在开放时间内 ({start}:00-{end}:00)"
                else:
                    msg = f"❌ 当前时间 {hour}:00 不在开放时间内 ({start}:00-{end}:00)"
            if config.get('password'):
                msg += " | 🔑 需要密码"
        else:
            msg = "未知操作"
        
        videos = [
            {"vod_id": "back", "vod_name": "← 返回设置", "vod_pic": "", "vod_remarks": msg},
        ]
        return {"class": [], "list": videos}
    
    def detailContent(self, ids):
        return {"list": []}
    
    def playerContent(self, flag, id, vipFlags):
        return {"parse": 0, "url": "", "header": {}}
    
    def searchContent(self, key, quick, pg=1):
        return {"list": []}
    
    def localProxy(self, param):
        return {}
    
    def destroy(self):
        pass
