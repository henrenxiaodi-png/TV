#!/usr/bin/python
# coding=utf-8
"""
午夜电影 - 带密码和开放时间控制
- 访问密码：在搜索框输入密码验证
- 开放时间：设置允许访问的时间段
- 配置保存在本地文件
"""
import os
import json
import re
import time

PY_DIR = "/storage/emulated/0/海豚TV/py"
SOURCES_DIR = os.path.join(PY_DIR, ".sources")
WUYE_CONFIG_FILE = os.path.join(PY_DIR, "wuye_config.json")

def _load_wuye_config():
    if os.path.exists(WUYE_CONFIG_FILE):
        try:
            with open(WUYE_CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {"password": "", "start_hour": 20, "end_hour": 5, "enabled": False}

def _check_wuye_access():
    """检查午夜电影访问权限，返回(可访问, 提示信息)"""
    config = _load_wuye_config()
    if not config.get('enabled'):
        return True, ""
    # 检查时间
    import time
    now = time.localtime()
    hour = now.tm_hour
    start = config.get('start_hour', 20)
    end = config.get('end_hour', 5)
    in_time = False
    if start <= end:
        in_time = start <= hour < end
    else:
        in_time = hour >= start or hour < end
    if not in_time:
        return False, f"⏰ 当前时间 {hour}:00 不在开放时间内 ({start}:00-{end}:00)"
    # 检查密码（有密码需要输入，这里简单处理：有密码就提示）
    if config.get('password'):
        return False, f"🔒 需要访问密码，请在'午夜电影控制'中设置或输入密码"
    return True, ""
CONFIG_FILE = os.path.join(PY_DIR, ".wuye_config.json")
AUTH_FILE = os.path.join(PY_DIR, ".wuye_auth")

# 内置源列表（按名称排序）
SOURCES = sorted([
    {"filename": "[│╔╚╦]▒¼╞¼┐Γ.py", "name": "🎬 [│╔╚╦]▒¼╞¼┐Γ"},
    {"filename": "[┬╫└φ]╙┼╩╙╞╡.py", "name": "🎬 [┬╫└φ]╙┼╩╙╞╡"},
    {"filename": "[伦理]优视频.py", "name": "🎬 [伦理]优视频"},
    {"filename": "[伦理]向上影院🔞.py", "name": "🎬 [伦理]向上影院🔞"},
    {"filename": "[伦理]大师兄影视🔞.py", "name": "🎬 [伦理]大师兄影视🔞"},
    {"filename": "[伦理]大米星球🔞.py", "name": "🎬 [伦理]大米星球🔞"},
    {"filename": "[伦理]小鸭子看看🔞.py", "name": "🎬 [伦理]小鸭子看看🔞"},
    {"filename": "[伦理]艾旦影视🔞.py", "name": "🎬 [伦理]艾旦影视🔞"},
    {"filename": "[伦理]青蛙影视🔞.py", "name": "🎬 [伦理]青蛙影视🔞"},
    {"filename": "[伦理]韩剧巴士🔞.py", "name": "🎬 [伦理]韩剧巴士🔞"},
    {"filename": "[吃瓜]007吃瓜🔞.py", "name": "🎬 [吃瓜]007吃瓜🔞"},
    {"filename": "[吃瓜]51吃瓜🔞.py", "name": "🎬 [吃瓜]51吃瓜🔞"},
    {"filename": "[吃瓜]51大赛🔞.py", "name": "🎬 [吃瓜]51大赛🔞"},
    {"filename": "[吃瓜]51暗网🔞.py", "name": "🎬 [吃瓜]51暗网🔞"},
    {"filename": "[吃瓜]51爆料🔞.py", "name": "🎬 [吃瓜]51爆料🔞"},
    {"filename": "[吃瓜]51视频🔞.py", "name": "🎬 [吃瓜]51视频🔞"},
    {"filename": "[吃瓜]818黑料网🔞.py", "name": "🎬 [吃瓜]818黑料网🔞"},
    {"filename": "[吃瓜]911爆料🔞.py", "name": "🎬 [吃瓜]911爆料🔞"},
    {"filename": "[吃瓜]91吃瓜中心🔞.py", "name": "🎬 [吃瓜]91吃瓜中心🔞"},
    {"filename": "[吃瓜]91大赛(无封面)🔞.py", "name": "🎬 [吃瓜]91大赛(无封面)🔞"},
    {"filename": "[吃瓜]91爆料🔞.py", "name": "🎬 [吃瓜]91爆料🔞"},
    {"filename": "[吃瓜]今日看料🔞.py", "name": "🎬 [吃瓜]今日看料🔞"},
    {"filename": "[吃瓜]每日大乱斗🔞.py", "name": "🎬 [吃瓜]每日大乱斗🔞"},
    {"filename": "[吃瓜]每日大赛🔞.py", "name": "🎬 [吃瓜]每日大赛🔞"},
    {"filename": "[吃瓜]爆瓜网🔞.py", "name": "🎬 [吃瓜]爆瓜网🔞"},
    {"filename": "[吃瓜]黑料不打烊🔞.py", "name": "🎬 [吃瓜]黑料不打烊🔞"},
    {"filename": "[吃瓜]黑料网🔞.py", "name": "🎬 [吃瓜]黑料网🔞"},
    {"filename": "[成人]123AV2🔞.py", "name": "🎬 [成人]123AV2🔞"},
    {"filename": "[成人]123av🔞.py", "name": "🎬 [成人]123av🔞"},
    {"filename": "[成人]18AV🔞.py", "name": "🎬 [成人]18AV🔞"},
    {"filename": "[成人]18jtv🔞.py", "name": "🎬 [成人]18jtv🔞"},
    {"filename": "[成人]2048核基地🔞.py", "name": "🎬 [成人]2048核基地🔞"},
    {"filename": "[成人]51FANS🔞.py", "name": "🎬 [成人]51FANS🔞"},
    {"filename": "[成人]777午夜影院🔞.py", "name": "🎬 [成人]777午夜影院🔞"},
    {"filename": "[成人]8X8X🔞.py", "name": "🎬 [成人]8X8X🔞"},
    {"filename": "[成人]91Porn蝌蚪窝🔞.py", "name": "🎬 [成人]91Porn蝌蚪窝🔞"},
    {"filename": "[成人]91porna🔞.py", "name": "🎬 [成人]91porna🔞"},
    {"filename": "[成人]91porn🔞.py", "name": "🎬 [成人]91porn🔞"},
    {"filename": "[成人]91热爆🔞.py", "name": "🎬 [成人]91热爆🔞"},
    {"filename": "[成人]9g88x🔞.py", "name": "🎬 [成人]9g88x🔞"},
    {"filename": "[成人]AVTOP10🔞.py", "name": "🎬 [成人]AVTOP10🔞"},
    {"filename": "[成人]AVToday🔞.py", "name": "🎬 [成人]AVToday🔞"},
    {"filename": "[成人]AV星球🔞.py", "name": "🎬 [成人]AV星球🔞"},
    {"filename": "[成人]AdultpornaAV🔞.py", "name": "🎬 [成人]AdultpornaAV🔞"},
    {"filename": "[成人]BadNew🔞s.py", "name": "🎬 [成人]BadNew🔞s"},
    {"filename": "[成人]Beeg🔞.py", "name": "🎬 [成人]Beeg🔞"},
    {"filename": "[成人]EPORNER🔞.py", "name": "🎬 [成人]EPORNER🔞"},
    {"filename": "[成人]FullHD🔞.py", "name": "🎬 [成人]FullHD🔞"},
    {"filename": "[成人]GG51🔞.py", "name": "🎬 [成人]GG51🔞"},
    {"filename": "[成人]Huoporn🔞.py", "name": "🎬 [成人]Huoporn🔞"},
    {"filename": "[成人]JAV36🔞.py", "name": "🎬 [成人]JAV36🔞"},
    {"filename": "[成人]JAVMove(羊壳)🔞.py", "name": "🎬 [成人]JAVMove(羊壳)🔞"},
    {"filename": "[成人]JK领域🔞.py", "name": "🎬 [成人]JK领域🔞"},
    {"filename": "[成人]Jable🔞.py", "name": "🎬 [成人]Jable🔞"},
    {"filename": "[成人]Javbunny(羊壳)🔞.py", "name": "🎬 [成人]Javbunny(羊壳)🔞"},
    {"filename": "[成人]Javmenu🔞.py", "name": "🎬 [成人]Javmenu🔞"},
    {"filename": "[成人]MSAVX🔞.py", "name": "🎬 [成人]MSAVX🔞"},
    {"filename": "[成人]PigAV🔞.py", "name": "🎬 [成人]PigAV🔞"},
    {"filename": "[成人]Pornhub🔞.py", "name": "🎬 [成人]Pornhub🔞"},
    {"filename": "[成人]TOPTV🔞.py", "name": "🎬 [成人]TOPTV🔞"},
    {"filename": "[成人]ThumbzillaTop(羊壳)🔞.py", "name": "🎬 [成人]ThumbzillaTop(羊壳)🔞"},
    {"filename": "[成人]TnAflix🔞.py", "name": "🎬 [成人]TnAflix🔞"},
    {"filename": "[成人]UAA🔞.py", "name": "🎬 [成人]UAA🔞"},
    {"filename": "[成人]UU视视APP🔞.py", "name": "🎬 [成人]UU视视APP🔞"},
    {"filename": "[成人]VF四级老片🔞.py", "name": "🎬 [成人]VF四级老片🔞"},
    {"filename": "[成人]VHUB🔞.py", "name": "🎬 [成人]VHUB🔞"},
    {"filename": "[成人]VV视频🔞.py", "name": "🎬 [成人]VV视频🔞"},
    {"filename": "[成人]XX01🔞.py", "name": "🎬 [成人]XX01🔞"},
    {"filename": "[成人]Xvideos🔞.py", "name": "🎬 [成人]Xvideos🔞"},
    {"filename": "[成人]av3698🔞.py", "name": "🎬 [成人]av3698🔞"},
    {"filename": "[成人]avgood🔞.py", "name": "🎬 [成人]avgood🔞"},
    {"filename": "[成人]fulao2🔞.py", "name": "🎬 [成人]fulao2🔞"},
    {"filename": "[成人]fulleroticmovies怀旧经典🔞.py", "name": "🎬 [成人]fulleroticmovies怀旧经典🔞"},
    {"filename": "[成人]hqg🔞.py", "name": "🎬 [成人]hqg🔞"},
    {"filename": "[成人]hubff🔞.py", "name": "🎬 [成人]hubff🔞"},
    {"filename": "[成人]iSese影库🔞.py", "name": "🎬 [成人]iSese影库🔞"},
    {"filename": "[成人]javGG(羊壳)🔞.py", "name": "🎬 [成人]javGG(羊壳)🔞"},
    {"filename": "[成人]javfree🔞.py", "name": "🎬 [成人]javfree🔞"},
    {"filename": "[成人]javhd🔞.py", "name": "🎬 [成人]javhd🔞"},
    {"filename": "[成人]kiss🔞.py", "name": "🎬 [成人]kiss🔞"},
    {"filename": "[成人]lmlgdjr🔞.py", "name": "🎬 [成人]lmlgdjr🔞"},
    {"filename": "[成人]missav1🔞.py", "name": "🎬 [成人]missav1🔞"},
    {"filename": "[成人]netfapx🔞.py", "name": "🎬 [成人]netfapx🔞"},
    {"filename": "[成人]okxxx(羊壳)🔞.py", "name": "🎬 [成人]okxxx(羊壳)🔞"},
    {"filename": "[成人]one🔞.py", "name": "🎬 [成人]one🔞"},
    {"filename": "[成人]owoav🔞.py", "name": "🎬 [成人]owoav🔞"},
    {"filename": "[成人]paradisehill(羊壳)🔞.py", "name": "🎬 [成人]paradisehill(羊壳)🔞"},
    {"filename": "[成人]pmvhaven(羊壳)🔞.py", "name": "🎬 [成人]pmvhaven(羊壳)🔞"},
    {"filename": "[成人]pornlulu🔞.py", "name": "🎬 [成人]pornlulu🔞"},
    {"filename": "[成人]xhamster🔞.py", "name": "🎬 [成人]xhamster🔞"},
    {"filename": "[成人]xxbrits🔞.py", "name": "🎬 [成人]xxbrits🔞"},
    {"filename": "[成人]youav🔞.py", "name": "🎬 [成人]youav🔞"},
    {"filename": "[成人]一牛影视🔞.py", "name": "🎬 [成人]一牛影视🔞"},
    {"filename": "[成人]一起草🔞.py", "name": "🎬 [成人]一起草🔞"},
    {"filename": "[成人]七色谷🔞.py", "name": "🎬 [成人]七色谷🔞"},
    {"filename": "[成人]三流视频🔞.py", "name": "🎬 [成人]三流视频🔞"},
    {"filename": "[成人]专草校花🔞.py", "name": "🎬 [成人]专草校花🔞"},
    {"filename": "[成人]丝袜乐土🔞.py", "name": "🎬 [成人]丝袜乐土🔞"},
    {"filename": "[成人]久久視頻🔞.py", "name": "🎬 [成人]久久視頻🔞"},
    {"filename": "[成人]久夜AV🔞.py", "name": "🎬 [成人]久夜AV🔞"},
    {"filename": "[成人]九阴争茎🔞.py", "name": "🎬 [成人]九阴争茎🔞"},
    {"filename": "[成人]乱伦48小时🔞.py", "name": "🎬 [成人]乱伦48小时🔞"},
    {"filename": "[成人]乱伦仓库🔞.py", "name": "🎬 [成人]乱伦仓库🔞"},
    {"filename": "[成人]乱伦伊甸园🔞.py", "name": "🎬 [成人]乱伦伊甸园🔞"},
    {"filename": "[成人]五月天🔞.py", "name": "🎬 [成人]五月天🔞"},
    {"filename": "[成人]五月星空🔞.py", "name": "🎬 [成人]五月星空🔞"},
    {"filename": "[成人]亚色影库🔞.py", "name": "🎬 [成人]亚色影库🔞"},
    {"filename": "[成人]京东淫联🔞.py", "name": "🎬 [成人]京东淫联🔞"},
    {"filename": "[成人]人妻偷情🔞.py", "name": "🎬 [成人]人妻偷情🔞"},
    {"filename": "[成人]优质粉嫩鲍🔞.py", "name": "🎬 [成人]优质粉嫩鲍🔞"},
    {"filename": "[成人]低端影视成人🔞.py", "name": "🎬 [成人]低端影视成人🔞"},
    {"filename": "[成人]儿子上穴🔞.py", "name": "🎬 [成人]儿子上穴🔞"},
    {"filename": "[成人]午夜福利(羊壳)🔞.py", "name": "🎬 [成人]午夜福利(羊壳)🔞"},
    {"filename": "[成人]口爆大全AV🔞.py", "name": "🎬 [成人]口爆大全AV🔞"},
    {"filename": "[成人]善良的小姨子🔞.py", "name": "🎬 [成人]善良的小姨子🔞"},
    {"filename": "[成人]四色🔞.py", "name": "🎬 [成人]四色🔞"},
    {"filename": "[成人]四虎视频🔞.py", "name": "🎬 [成人]四虎视频🔞"},
    {"filename": "[成人]国色天香🔞.py", "name": "🎬 [成人]国色天香🔞"},
    {"filename": "[成人]夜社🔞.py", "name": "🎬 [成人]夜社🔞"},
    {"filename": "[成人]夜色🔞.py", "name": "🎬 [成人]夜色🔞"},
    {"filename": "[成人]大屌视频🔞.py", "name": "🎬 [成人]大屌视频🔞"},
    {"filename": "[成人]大鸡吧🔞.py", "name": "🎬 [成人]大鸡吧🔞"},
    {"filename": "[成人]奶糖视频🔞.py", "name": "🎬 [成人]奶糖视频🔞"},
    {"filename": "[成人]好莱污影院🔞.py", "name": "🎬 [成人]好莱污影院🔞"},
    {"filename": "[成人]妈妈自拍🔞.py", "name": "🎬 [成人]妈妈自拍🔞"},
    {"filename": "[成人]妲己🔞.py", "name": "🎬 [成人]妲己🔞"},
    {"filename": "[成人]寂寞阿姨🔞.py", "name": "🎬 [成人]寂寞阿姨🔞"},
    {"filename": "[成人]密云视频🔞.py", "name": "🎬 [成人]密云视频🔞"},
    {"filename": "[成人]小学妹🔞.py", "name": "🎬 [成人]小学妹🔞"},
    {"filename": "[成人]小心御欲🔞.py", "name": "🎬 [成人]小心御欲🔞"},
    {"filename": "[成人]小涩界🔞.py", "name": "🎬 [成人]小涩界🔞"},
    {"filename": "[成人]小男娘🔞.py", "name": "🎬 [成人]小男娘🔞"},
    {"filename": "[成人]小红薯APP🔞.py", "name": "🎬 [成人]小红薯APP🔞"},
    {"filename": "[成人]少妇喝多了🔞.py", "name": "🎬 [成人]少妇喝多了🔞"},
    {"filename": "[成人]幸福加油站🔞.py", "name": "🎬 [成人]幸福加油站🔞"},
    {"filename": "[成人]徐娘阁🔞.py", "name": "🎬 [成人]徐娘阁🔞"},
    {"filename": "[成人]怡红院🔞.py", "name": "🎬 [成人]怡红院🔞"},
    {"filename": "[成人]怦然心动🔞.py", "name": "🎬 [成人]怦然心动🔞"},
    {"filename": "[成人]性运机场🔞.py", "name": "🎬 [成人]性运机场🔞"},
    {"filename": "[成人]悟空传媒🔞.py", "name": "🎬 [成人]悟空传媒🔞"},
    {"filename": "[成人]成人乐园🔞.py", "name": "🎬 [成人]成人乐园🔞"},
    {"filename": "[成人]成人文化馆(羊壳)🔞.py", "name": "🎬 [成人]成人文化馆(羊壳)🔞"},
    {"filename": "[成人]房中㊙️术🔞.py", "name": "🎬 [成人]房中㊙️术🔞"},
    {"filename": "[成人]手鸡助手🔞.py", "name": "🎬 [成人]手鸡助手🔞"},
    {"filename": "[成人]拍摄现场🔞.py", "name": "🎬 [成人]拍摄现场🔞"},
    {"filename": "[成人]换母俱乐部🔞.py", "name": "🎬 [成人]换母俱乐部🔞"},
    {"filename": "[成人]推特APP🔞.py", "name": "🎬 [成人]推特APP🔞"},
    {"filename": "[成人]推特涩涩🔞.py", "name": "🎬 [成人]推特涩涩🔞"},
    {"filename": "[成人]撸一天🔞.py", "name": "🎬 [成人]撸一天🔞"},
    {"filename": "[成人]撸壮元🔞.py", "name": "🎬 [成人]撸壮元🔞"},
    {"filename": "[成人]撸王宝典🔞.py", "name": "🎬 [成人]撸王宝典🔞"},
    {"filename": "[成人]教授🔞.py", "name": "🎬 [成人]教授🔞"},
    {"filename": "[成人]智者玩水🔞.py", "name": "🎬 [成人]智者玩水🔞"},
    {"filename": "[成人]权色视频🔞.py", "name": "🎬 [成人]权色视频🔞"},
    {"filename": "[成人]杏吧视频🔞.py", "name": "🎬 [成人]杏吧视频🔞"},
    {"filename": "[成人]极品少女🔞.py", "name": "🎬 [成人]极品少女🔞"},
    {"filename": "[成人]果冻传媒(羊壳)🔞.py", "name": "🎬 [成人]果冻传媒(羊壳)🔞"},
    {"filename": "[成人]樱花传媒🔞.py", "name": "🎬 [成人]樱花传媒🔞"},
    {"filename": "[成人]橘子资源🔞.py", "name": "🎬 [成人]橘子资源🔞"},
    {"filename": "[成人]正妹AV🔞.py", "name": "🎬 [成人]正妹AV🔞"},
    {"filename": "[成人]母夜插插插🔞.py", "name": "🎬 [成人]母夜插插插🔞"},
    {"filename": "[成人]气泡视频🔞.py", "name": "🎬 [成人]气泡视频🔞"},
    {"filename": "[成人]河马影视🔞.py", "name": "🎬 [成人]河马影视🔞"},
    {"filename": "[成人]海角乱伦🔞.py", "name": "🎬 [成人]海角乱伦🔞"},
    {"filename": "[成人]淫兽穴院🔞.py", "name": "🎬 [成人]淫兽穴院🔞"},
    {"filename": "[成人]淫母原味🔞.py", "name": "🎬 [成人]淫母原味🔞"},
    {"filename": "[成人]淫水洞🔞.py", "name": "🎬 [成人]淫水洞🔞"},
    {"filename": "[成人]清纯人妻🔞.py", "name": "🎬 [成人]清纯人妻🔞"},
    {"filename": "[成人]清纯富婆🔞.py", "name": "🎬 [成人]清纯富婆🔞"},
    {"filename": "[成人]溏心次元🔞.py", "name": "🎬 [成人]溏心次元🔞"},
    {"filename": "[成人]熊猫视频🔞.py", "name": "🎬 [成人]熊猫视频🔞"},
    {"filename": "[成人]熟女汇🔞.py", "name": "🎬 [成人]熟女汇🔞"},
    {"filename": "[成人]熟妇天堂🔞.py", "name": "🎬 [成人]熟妇天堂🔞"},
    {"filename": "[成人]爆片库.py", "name": "🎬 [成人]爆片库"},
    {"filename": "[成人]爆色🔞.py", "name": "🎬 [成人]爆色🔞"},
    {"filename": "[成人]猫咪AV🔞.py", "name": "🎬 [成人]猫咪AV🔞"},
    {"filename": "[成人]猫咪视频AV(羊壳)🔞.py", "name": "🎬 [成人]猫咪视频AV(羊壳)🔞"},
    {"filename": "[成人]玉蚌含珠🔞.py", "name": "🎬 [成人]玉蚌含珠🔞"},
    {"filename": "[成人]玩物社区🔞.py", "name": "🎬 [成人]玩物社区🔞"},
    {"filename": "[成人]玩蛋吧🔞.py", "name": "🎬 [成人]玩蛋吧🔞"},
    {"filename": "[成人]男人本色🔞.py", "name": "🎬 [成人]男人本色🔞"},
    {"filename": "[成人]百合TV🔞.py", "name": "🎬 [成人]百合TV🔞"},
    {"filename": "[成人]直播录屏🔞.py", "name": "🎬 [成人]直播录屏🔞"},
    {"filename": "[成人]真实人妻🔞.py", "name": "🎬 [成人]真实人妻🔞"},
    {"filename": "[成人]真实未流出🔞.py", "name": "🎬 [成人]真实未流出🔞"},
    {"filename": "[成人]神秘电影🔞.py", "name": "🎬 [成人]神秘电影🔞"},
    {"filename": "[成人]禁片天堂🔞.py", "name": "🎬 [成人]禁片天堂🔞"},
    {"filename": "[成人]福利天堂🔞.py", "name": "🎬 [成人]福利天堂🔞"},
    {"filename": "[成人]笔盒🔞.py", "name": "🎬 [成人]笔盒🔞"},
    {"filename": "[成人]精英突击🔞.py", "name": "🎬 [成人]精英突击🔞"},
    {"filename": "[成人]糖心Vlog网页2🔞.py", "name": "🎬 [成人]糖心Vlog网页2🔞"},
    {"filename": "[成人]糖心Vlog网页🔞.py", "name": "🎬 [成人]糖心Vlog网页🔞"},
    {"filename": "[成人]肉视频🔞.py", "name": "🎬 [成人]肉视频🔞"},
    {"filename": "[成人]色吧资源🔞.py", "name": "🎬 [成人]色吧资源🔞"},
    {"filename": "[成人]色播聚合🔞.py", "name": "🎬 [成人]色播聚合🔞"},
    {"filename": "[成人]花都影视🔞.py", "name": "🎬 [成人]花都影视🔞"},
    {"filename": "[成人]草榴社区🔞.py", "name": "🎬 [成人]草榴社区🔞"},
    {"filename": "[成人]草榴视频区🔞.py", "name": "🎬 [成人]草榴视频区🔞"},
    {"filename": "[成人]萝莉AV🔞.py", "name": "🎬 [成人]萝莉AV🔞"},
    {"filename": "[成人]萝莉聚集🔞.py", "name": "🎬 [成人]萝莉聚集🔞"},
    {"filename": "[成人]蜜桃AV🔞.py", "name": "🎬 [成人]蜜桃AV🔞"},
    {"filename": "[成人]蜜桃源🔞.py", "name": "🎬 [成人]蜜桃源🔞"},
    {"filename": "[成人]蜜桃视频(羊壳)🔞.py", "name": "🎬 [成人]蜜桃视频(羊壳)🔞"},
    {"filename": "[成人]西瓜视频🔞.py", "name": "🎬 [成人]西瓜视频🔞"},
    {"filename": "[成人]迷妹网(羊壳)🔞.py", "name": "🎬 [成人]迷妹网(羊壳)🔞"},
    {"filename": "[成人]采花大盗🔞.py", "name": "🎬 [成人]采花大盗🔞"},
    {"filename": "[成人]采集聚合成人🔞.py", "name": "🎬 [成人]采集聚合成人🔞"},
    {"filename": "[成人]野马中文🔞.py", "name": "🎬 [成人]野马中文🔞"},
    {"filename": "[成人]阴阳宝鉴🔞.py", "name": "🎬 [成人]阴阳宝鉴🔞"},
    {"filename": "[成人]陌陌一夜情🔞.py", "name": "🎬 [成人]陌陌一夜情🔞"},
    {"filename": "[成人]韩国色情电影🔞.py", "name": "🎬 [成人]韩国色情电影🔞"},
    {"filename": "[成人]香肠派对🔞.py", "name": "🎬 [成人]香肠派对🔞"},
    {"filename": "[成人]香蕉视频🔞.py", "name": "🎬 [成人]香蕉视频🔞"},
    {"filename": "[成人]骚女档案馆🔞.py", "name": "🎬 [成人]骚女档案馆🔞"},
    {"filename": "[成人]魑魅魍魉🔞.py", "name": "🎬 [成人]魑魅魍魉🔞"},
    {"filename": "[成人]魔色365🔞.py", "name": "🎬 [成人]魔色365🔞"},
    {"filename": "[成人]麻豆免费在线播放🔞.py", "name": "🎬 [成人]麻豆免费在线播放🔞"},
    {"filename": "[成人]麻豆影院🔞.py", "name": "🎬 [成人]麻豆影院🔞"},
    {"filename": "[成人]麻豆社🔞.py", "name": "🎬 [成人]麻豆社🔞"},
    {"filename": "[成人]黄色仓库动态版🔞.py", "name": "🎬 [成人]黄色仓库动态版🔞"},
    {"filename": "[成人]黄色仓库🔞.py", "name": "🎬 [成人]黄色仓库🔞"},
    {"filename": "[成人]黄豆短剧🔞.py", "name": "🎬 [成人]黄豆短剧🔞"},
    {"filename": "[成人动漫]HS日本4K动漫🔞.py", "name": "🎬 [成人动漫]HS日本4K动漫🔞"},
    {"filename": "[成人动漫]NaughtyMachinima🔞.py", "name": "🎬 [成人动漫]NaughtyMachinima🔞"},
    {"filename": "[成人动漫]hanime1🔞.py", "name": "🎬 [成人动漫]hanime1🔞"},
    {"filename": "[成人动漫]樱花动漫🔞.py", "name": "🎬 [成人动漫]樱花动漫🔞"},
    {"filename": "[成人听书]ASMR听书🔞.py", "name": "🎬 [成人听书]ASMR听书🔞"},
    {"filename": "[成人听书]有声骚麦🔞.py", "name": "🎬 [成人听书]有声骚麦🔞"},
    {"filename": "[成人直播]Cam4直播🔞.py", "name": "🎬 [成人直播]Cam4直播🔞"},
    {"filename": "[成人直播]Chaturbate2🔞.py", "name": "🎬 [成人直播]Chaturbate2🔞"},
    {"filename": "[成人直播]Chaturbate🔞.py", "name": "🎬 [成人直播]Chaturbate🔞"},
    {"filename": "[成人直播]Pandalive直播🔞.py", "name": "🎬 [成人直播]Pandalive直播🔞"},
    {"filename": "[成人直播]myfreecams直播🔞.py", "name": "🎬 [成人直播]myfreecams直播🔞"},
    {"filename": "[成人直播]stripchat🔞.py", "name": "🎬 [成人直播]stripchat🔞"},
    {"filename": "[成人短剧]51短剧🔞.py", "name": "🎬 [成人短剧]51短剧🔞"},
    {"filename": "[成人短剧]一抖阁🔞.py", "name": "🎬 [成人短剧]一抖阁🔞"},
    {"filename": "[成人短剧]狂飙短剧🔞.py", "name": "🎬 [成人短剧]狂飙短剧🔞"},
    {"filename": "bainian_live.py", "name": "🎬 bainian_live"},
    {"filename": "gaokao.py", "name": "🎬 gaokao"},
    {"filename": "gaoqing.py", "name": "🎬 gaoqing"},
    {"filename": "javdb_aowu.py", "name": "🎬 javdb_aowu"},
    {"filename": "mengnan.py", "name": "🎬 mengnan"},
    {"filename": "qisegu.py", "name": "🎬 qisegu"},
    {"filename": "supjav.py", "name": "🎬 supjav"},
    {"filename": "weimei.py", "name": "🎬 weimei"},
], key=lambda x: x['name'])

NAME_MAP = {s['filename']: s['name'] for s in SOURCES}

try:
    from base.spider import Spider as _BaseSpider
except ImportError:
    class _BaseSpider:
        pass

def _load_config():
    """加载配置"""
    default_config = {
        "password": "",  # 访问密码，空表示不需要密码
        "start_time": "20:00",  # 开放开始时间
        "end_time": "05:00",  # 开放结束时间
        "time_enabled": False,  # 是否启用开放时间限制
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                default_config.update(config)
        except:
            pass
    return default_config

def _save_config(config):
    """保存配置"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except:
        pass

def _is_authed():
    """检查是否已认证"""
    if os.path.exists(AUTH_FILE):
        try:
            with open(AUTH_FILE, 'r') as f:
                ts = float(f.read().strip())
                # 认证有效期2小时
                if time.time() - ts < 7200:
                    return True
        except:
            pass
    return False

def _set_authed():
    """设置已认证"""
    try:
        with open(AUTH_FILE, 'w') as f:
            f.write(str(time.time()))
    except:
        pass

def _check_time(config):
    """检查当前时间是否在开放时间内"""
    if not config.get("time_enabled", False):
        return True
    try:
        now = time.localtime()
        current_minutes = now.tm_hour * 60 + now.tm_min
        start_parts = config.get("start_time", "20:00").split(":")
        end_parts = config.get("end_time", "05:00").split(":")
        start_minutes = int(start_parts[0]) * 60 + int(start_parts[1])
        end_minutes = int(end_parts[0]) * 60 + int(end_parts[1])
        if start_minutes <= end_minutes:
            return start_minutes <= current_minutes <= end_minutes
        else:
            # 跨天，如20:00到05:00
            return current_minutes >= start_minutes or current_minutes <= end_minutes
    except:
        return True

class Spider(_BaseSpider):
    filterable = True
    
    def __init__(self):
        try:
            super().__init__()
        except Exception:
            pass
        self.name = "🌙 午夜电影"
        self.ext = ""
    
    def getName(self):
        return self.name
    
    def init(self, extend=""):
        self.ext = extend
    
    def _load_source(self, filename):
        """动态加载py源并返回Spider实例"""
        filepath = os.path.join(SOURCES_DIR, filename)
        if not os.path.exists(filepath):
            filepath = os.path.join(PY_DIR, filename)
        if not os.path.exists(filepath):
            return None
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("wuye_src", filepath)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if hasattr(mod, 'Spider'):
                spider = mod.Spider()
                if hasattr(spider, 'init'):
                    spider.init("")
                return spider
        except Exception:
            pass
        return None
    
    def _check_access(self):
        """检查访问权限，返回(是否允许, 提示信息)"""
        config = _load_config()
        # 检查开放时间
        if not _check_time(config):
            return False, f"⏰ 当前不在开放时间内\n开放时间: {config.get('start_time', '20:00')} - {config.get('end_time', '05:00')}"
        # 检查密码
        if config.get("password", "") and not _is_authed():
            return False, "🔒 请输入访问密码\n（在搜索框输入密码后搜索）"
        return True, ""
    
    # ==================== 首页 ====================
    def homeContent(self, filter):
        """首页：检查访问权限，通过后返回py站点列表"""
        allowed, msg = self._check_access()
        if not allowed:
            # 返回锁定界面
            videos = [
                {"vod_id": "locked", "vod_name": "🔒 午夜电影已锁定", "vod_pic": "", "vod_remarks": msg},
                {"vod_id": "tip_password", "vod_name": "🔑 输入密码访问", "vod_pic": "", "vod_remarks": "在搜索框输入密码后点击搜索"},
                {"vod_id": "tip_time", "vod_name": "⏰ 开放时间设置", "vod_pic": "", "vod_remarks": "配置文件: .wuye_config.json"},
            ]
            return {"class": [], "list": videos}
        
        # 已通过验证，返回正常内容
        classes = []
        for src in SOURCES:
            classes.append({
                "type_id": src['filename'],
                "type_name": src['name']
            })
        return {"class": classes}
    
    def homeVideoContent(self):
        return {"list": []}
    
    # ==================== 分类内容 ====================
    def categoryContent(self, tid, pg, filter, extend):
        """分类内容"""
        # 检查访问权限
        allowed, msg = self._check_access()
        if not allowed:
            return {"list": [{"vod_id": "locked", "vod_name": "🔒 访问受限", "vod_pic": "", "vod_remarks": msg}]}
        
        # 第二级：站点:分类ID -> 返回视频列表
        if ":" in tid:
            parts = tid.split(":", 1)
            filename = parts[0]
            sub_tid = parts[1]
            spider = self._load_source(filename)
            if spider and hasattr(spider, 'categoryContent'):
                try:
                    result = spider.categoryContent(sub_tid, pg, filter, extend)
                    if isinstance(result, str):
                        result = json.loads(result)
                    # 给每个视频ID加上站点前缀
                    if 'list' in result:
                        for v in result['list']:
                            if 'vod_id' in v:
                                v['vod_id'] = filename + "::" + str(v['vod_id'])
                    return result
                except Exception as e:
                    return {"list": [{"vod_id": "error", "vod_name": "❌ 加载失败", "vod_pic": "", "vod_remarks": str(e)[:100]}]}
            return {"list": []}
        
        # 第一级：站点文件名 -> 返回该站点的分类列表
        filename = tid
        if filename not in NAME_MAP:
            return {"list": []}
        
        spider = self._load_source(filename)
        if spider and hasattr(spider, 'homeContent'):
            try:
                result = spider.homeContent(False)
                if isinstance(result, str):
                    result = json.loads(result)
                videos = []
                if 'class' in result and result['class']:
                    for c in result['class']:
                        videos.append({
                            "vod_id": filename + ":" + str(c.get('type_id', '')),
                            "vod_name": "📁 " + c.get('type_name', ''),
                            "vod_pic": "",
                            "vod_remarks": "点击进入视频列表",
                            "vod_tag": "folder"
                        })
                else:
                    videos.append({
                        "vod_id": "noclass",
                        "vod_name": "📂 该站点暂无分类",
                        "vod_pic": "",
                        "vod_remarks": "",
                    })
                return {"list": videos}
            except Exception as e:
                return {"list": [{"vod_id": "error", "vod_name": f"❌ 加载失败: {NAME_MAP.get(filename, filename)}", "vod_pic": "", "vod_remarks": str(e)[:100]}]}
        
        return {"list": [{"vod_id": "notfound", "vod_name": f"❌ 文件不存在: {filename}", "vod_pic": "", "vod_remarks": ""}]}
    
    # ==================== 详情 ====================
    def detailContent(self, ids):
        """详情页"""
        # 检查访问权限
        allowed, msg = self._check_access()
        if not allowed:
            return {"list": []}
        
        if not ids:
            return {"list": []}
        vid = ids[0] if isinstance(ids, list) else ids
        if "::" in str(vid):
            parts = str(vid).split("::", 1)
            filename = parts[0]
            real_vid = parts[1]
            spider = self._load_source(filename)
            if spider and hasattr(spider, 'detailContent'):
                try:
                    result = spider.detailContent([real_vid])
                    if isinstance(result, str):
                        result = json.loads(result)
                    # 给播放地址的url部分加上站点前缀（格式：集数$站点::url）
                    # 注意：不能加在整个"集数$url"前面，否则TVBox传给playerContent的id不包含前缀
                    if 'list' in result:
                        for v in result['list']:
                            if 'vod_play_url' in v:
                                urls = str(v.get('vod_play_url', ''))
                                if urls:
                                    # 检测线路分隔符
                                    line_sep = '$$$' if '$$$' in urls else '$$'
                                    new_lines = []
                                    for line in urls.split(line_sep):
                                        if not line.strip():
                                            new_lines.append(line)
                                            continue
                                        # 每个线路里的集数用#分隔，格式：集数$url
                                        new_eps = []
                                        for ep in line.split('#'):
                                            if not ep.strip():
                                                new_eps.append(ep)
                                                continue
                                            if '$' in ep:
                                                ep_name, ep_url = ep.split('$', 1)
                                                new_eps.append(ep_name + '$' + filename + '::' + ep_url)
                                            else:
                                                new_eps.append(filename + '::' + ep)
                                        new_lines.append('#'.join(new_eps))
                                    v['vod_play_url'] = line_sep.join(new_lines)
                    return result
                except Exception as e:
                    return {"list": [{"vod_id": vid, "vod_name": "❌ 详情加载失败", "vod_pic": "", "vod_content": str(e)[:200]}]}
        return {"list": []}
    
    # ==================== 播放 ====================
    def playerContent(self, flag, id, vipFlags):
        """播放"""
        # 检查访问权限
        allowed, msg = self._check_access()
        if not allowed:
            return {"parse": 0, "url": "", "header": {}}
        
        if "::" in str(id):
            parts = str(id).split("::", 1)
            filename = parts[0]
            real_id = parts[1]
            # 去掉flag$前缀
            if "$" in real_id:
                dollar_idx = real_id.index("$")
                url_part = real_id[dollar_idx+1:]
                if url_part.startswith("http") or url_part.startswith("/") or url_part.startswith("vod"):
                    real_id = url_part
            spider = self._load_source(filename)
            if spider and hasattr(spider, 'playerContent'):
                try:
                    result = spider.playerContent(flag, real_id, vipFlags)
                    if isinstance(result, str):
                        result = json.loads(result)
                    # 如果返回的是代理URL（包含127.0.0.1或proxy），添加wuye_site参数
                    if isinstance(result, dict) and "url" in result:
                        url = str(result.get("url", ""))
                        if ("127.0.0.1" in url or "proxy" in url) and "wuye_site=" not in url:
                            sep = "&" if "?" in url else "?"
                            result["url"] = url + sep + "wuye_site=" + filename
                    return result
                except Exception as e:
                    return {"parse": 0, "url": "", "header": {}, "error": str(e)[:100]}
        real_url = str(id)
        if "$" in real_url:
            dollar_idx = real_url.index("$")
            url_part = real_url[dollar_idx+1:]
            if url_part.startswith("http") or url_part.startswith("/"):
                real_url = url_part
        return {"parse": 0, "url": real_url, "header": {}}
    
    # ==================== 搜索（密码验证） ====================
    def searchContent(self, key, quick, pg=1):
        """搜索：用于密码验证"""
        config = _load_config()
        # 如果设置了密码，验证密码
        if config.get("password", ""):
            if str(key) == str(config["password"]):
                _set_authed()
                return {"list": [
                    {"vod_id": "success", "vod_name": "✅ 密码正确，访问已授权", "vod_pic": "", "vod_remarks": "有效期2小时，返回首页即可浏览"},
                    {"vod_id": "back", "vod_name": "← 返回午夜电影首页", "vod_pic": "", "vod_remarks": "点击返回"},
                ]}
            else:
                return {"list": [
                    {"vod_id": "wrong", "vod_name": "❌ 密码错误", "vod_pic": "", "vod_remarks": "请重新输入密码"},
                    {"vod_id": "tip", "vod_name": "💡 提示", "vod_pic": "", "vod_remarks": "在搜索框输入正确的访问密码"},
                ]}
        # 没有设置密码，直接搜索所有源
        all_videos = []
        for src in SOURCES:
            spider = self._load_source(src['filename'])
            if spider and hasattr(spider, 'searchContent'):
                try:
                    result = spider.searchContent(key, quick, pg)
                    if isinstance(result, str):
                        result = json.loads(result)
                    if 'list' in result:
                        for v in result['list']:
                            if 'vod_id' in v:
                                v['vod_id'] = src['filename'] + "::" + str(v['vod_id'])
                            all_videos.append(v)
                except:
                    pass
        return {"list": all_videos}
    
    def localProxy(self, param):
        """本地代理：根据URL参数判断是哪个站点的代理请求，路由到对应站点"""
        try:
            if isinstance(param, dict):
                target = param.get("url", "") or param.get("source", "") or ""
            else:
                target = str(param or "")
            # 从URL参数中提取站点信息（格式：wuye_site=站点文件名）
            import urllib.parse
            if "wuye_site=" in target:
                parsed = urllib.parse.urlparse(target)
                query_params = urllib.parse.parse_qs(parsed.query)
                site_name = query_params.get("wuye_site", [""])[0]
                if site_name and site_name in NAME_MAP:
                    spider = self._load_source(site_name)
                    if spider and hasattr(spider, 'localProxy'):
                        clean_url = target.replace("wuye_site=" + site_name, "")
                        clean_url = clean_url.replace("&&", "&").replace("?&", "?")
                        if clean_url.endswith("?"):
                            clean_url = clean_url[:-1]
                        if isinstance(param, dict):
                            new_param = dict(param)
                            new_param["url"] = clean_url
                        else:
                            new_param = clean_url
                        return spider.localProxy(new_param)
            return [404, "text/plain", b"not found"]
        except Exception as e:
            return [500, "text/plain", f"error: {str(e)}".encode("utf-8")]
    
    def destroy(self):
        pass
