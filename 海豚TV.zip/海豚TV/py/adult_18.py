#!/usr/bin/python
# coding=utf-8
"""
18㊙️成人区 - 带密码和开放时间控制
- 访问密码：在搜索框输入密码验证
- 开放时间：设置允许访问的时间段
- 配置保存在本地文件
"""
import os
import json
import re
import time

PY_DIR = "/storage/emulated/0/海豚TV/py"
# 18㊙️成人区py源目录（多种路径尝试，兼容中文编码问题）
ADULT_PY_DIRS = [
    "/storage/emulated/0/18禁",
    "/storage/emulated/0/18jin",
    "/storage/emulated/0/adult",
    "/sdcard/18禁",
    "/sdcard/adult",
]
# 也支持扫描手机根目录下的py文件
ROOT_PY_DIRS = [
    "/storage/emulated/0",
    "/sdcard",
]
SOURCES_DIR = os.path.join(PY_DIR, ".sources")
ADULT_CONFIG_FILE = os.path.join(PY_DIR, "adult_config.json")

def _load_adult_config():
    if os.path.exists(ADULT_CONFIG_FILE):
        try:
            with open(ADULT_CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {"password": "", "start_hour": 20, "end_hour": 5, "enabled": False}

def _check_adult_access():
    """检查18㊙️成人区访问权限，返回(可访问, 提示信息)"""
    config = _load_adult_config()
    if not config.get('enabled'):
        return True, ""
    # 检查时间
    import time
    now = time.localtime()
    hour = now.tm_hour
    start = config.get('start_hour', 20)
    end = config.get('end_hour', 5)
    in_time = False
    if start <= end:
        in_time = start <= hour < end
    else:
        in_time = hour >= start or hour < end
    if not in_time:
        return False, f"⏰ 18㊙️当前时间 {hour}:00 不在开放时间内 ({start}:00-{end}:00)"
    # 检查密码（有密码需要输入，这里简单处理：有密码就提示）
    if config.get('password'):
        return False, f"🔒 18㊙️需要访问密码，请在'18㊙️成人区控制'中设置或输入密码"
    return True, ""
CONFIG_FILE = os.path.join(PY_DIR, ".adult_config.json")
AUTH_FILE = os.path.join(PY_DIR, ".adult_auth")

# 内置源列表（按名称排序）
SOURCES = sorted([], key=lambda x: x['name'])

NAME_MAP = {s['filename']: s['name'] for s in SOURCES}

try:
    from base.spider import Spider as _BaseSpider
except ImportError:
    class _BaseSpider:
        pass

def _load_config():
    """加载配置"""
    default_config = {
        "password": "",  # 访问密码，空表示不需要密码
        "start_time": "20:00",  # 开放开始时间
        "end_time": "05:00",  # 开放结束时间
        "time_enabled": False,  # 是否启用开放时间限制
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                default_config.update(config)
        except:
            pass
    return default_config

def _save_config(config):
    """保存配置"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except:
        pass

def _is_authed():
    """检查是否已认证"""
    if os.path.exists(AUTH_FILE):
        try:
            with open(AUTH_FILE, 'r') as f:
                ts = float(f.read().strip())
                # 认证有效期2小时
                if time.time() - ts < 7200:
                    return True
        except:
            pass
    return False

def _set_authed():
    """设置已认证"""
    try:
        with open(AUTH_FILE, 'w') as f:
            f.write(str(time.time()))
    except:
        pass

def _check_time(config):
    """检查当前时间是否在开放时间内"""
    if not config.get("time_enabled", False):
        return True
    try:
        now = time.localtime()
        current_minutes = now.tm_hour * 60 + now.tm_min
        start_parts = config.get("start_time", "20:00").split(":")
        end_parts = config.get("end_time", "05:00").split(":")
        start_minutes = int(start_parts[0]) * 60 + int(start_parts[1])
        end_minutes = int(end_parts[0]) * 60 + int(end_parts[1])
        if start_minutes <= end_minutes:
            return start_minutes <= current_minutes <= end_minutes
        else:
            # 跨天，如20:00到05:00
            return current_minutes >= start_minutes or current_minutes <= end_minutes
    except:
        return True

class Spider(_BaseSpider):
    filterable = True
    
    def __init__(self):
        try:
            super().__init__()
        except Exception:
            pass
        self.name = "🌙 午夜电影"
        self.ext = ""
    
    def getName(self):
        return self.name
    
    def init(self, extend=""):
        self.ext = extend
    

    def _scan_py_files(self):
        """扫描手机根目录和18禁目录里的py文件，返回站点列表"""
        py_files = []
        seen = set()
        scan_errors = []
        # 扫描目录列表（多种路径尝试）
        scan_dirs = ADULT_PY_DIRS + ROOT_PY_DIRS
        for scan_dir in scan_dirs:
            try:
                if not os.path.exists(scan_dir):
                    scan_errors.append(f"路径不存在: {scan_dir}")
                    continue
                if not os.path.isdir(scan_dir):
                    scan_errors.append(f"不是目录: {scan_dir}")
                    continue
                files = os.listdir(scan_dir)
                for f in files:
                    if f.endswith('.py') and f not in seen:
                        # 排除系统文件和配置文件
                        if f.startswith('__') or f in ['list.py', 'wuye_movie.py', 'wuye_control.py', 'adult_18.py', 'resource_center.py']:
                            continue
                        filepath = os.path.join(scan_dir, f)
                        if os.path.isfile(filepath):
                            name = f[:-3] if f.endswith('.py') else f
                            py_files.append({
                                "filename": f,
                                "name": "🔞 " + name,
                                "path": filepath
                            })
                            seen.add(f)
            except Exception as e:
                scan_errors.append(f"扫描失败 {scan_dir}: {str(e)[:50]}")
        # 按名称排序
        py_files.sort(key=lambda x: x['name'])
        # 保存错误信息用于调试
        self._scan_errors = scan_errors
        return py_files

    def _load_source(self, filename):
        """动态加载py源并返回Spider实例，支持手机根目录任意路径"""
        filepath = None
        # 如果filename是完整路径
        if os.path.isabs(filename) and os.path.exists(filename):
            filepath = filename
        # 扫描目录里查找
        if not filepath:
            for scan_dir in [ADULT_PY_DIR, ROOT_PY_DIR, SOURCES_DIR, PY_DIR]:
                fp = os.path.join(scan_dir, os.path.basename(filename))
                if os.path.exists(fp):
                    filepath = fp
                    break
        if not filepath:
            return None
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("wuye_src", filepath)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if hasattr(mod, 'Spider'):
                spider = mod.Spider()
                if hasattr(spider, 'init'):
                    spider.init("")
                return spider
        except Exception:
            pass
        return None
    
    def _check_access(self):
        """检查访问权限，返回(是否允许, 提示信息)"""
        config = _load_config()
        # 检查开放时间
        if not _check_time(config):
            return False, f"⏰ 当前不在开放时间内\n开放时间: {config.get('start_time', '20:00')} - {config.get('end_time', '05:00')}"
        # 检查密码
        if config.get("password", "") and not _is_authed():
            return False, "🔒 请输入访问密码\n（在搜索框输入密码后搜索）"
        return True, ""
    
    # ==================== 首页 ====================
    def homeContent(self, filter):
        """首页：检查访问权限，通过后返回py站点列表"""
        allowed, msg = self._check_access()
        if not allowed:
            # 返回锁定界面
            videos = [
                {"vod_id": "locked", "vod_name": "🔒 午夜电影已锁定", "vod_pic": "", "vod_remarks": msg},
                {"vod_id": "tip_password", "vod_name": "🔑 输入密码访问", "vod_pic": "", "vod_remarks": "在搜索框输入密码后点击搜索"},
                {"vod_id": "tip_time", "vod_name": "⏰ 开放时间设置", "vod_pic": "", "vod_remarks": "配置文件: .adult_config.json"},
            ]
            return {"class": [], "list": videos}
        
        # 已通过验证，扫描手机根目录里的py文件
        py_files = self._scan_py_files()
        classes = []
        for src in py_files:
            classes.append({
                "type_id": src['path'],  # 使用完整路径
                "type_name": src['name']
            })
        # 如果没有找到py文件，显示调试信息
        if not classes:
            error_info = " | ".join(getattr(self, '_scan_errors', [])[:3])
            if error_info:
                classes = [{"type_id": "empty", "type_name": "📁 未找到py文件 - " + error_info[:60]}]
            else:
                classes = [{"type_id": "empty", "type_name": "📁 未找到py文件，请放到 /storage/emulated/0/18禁/ 目录"}]
        return {"class": classes}
    
    def homeVideoContent(self):
        return {"list": []}
    
    # ==================== 分类内容 ====================
    def categoryContent(self, tid, pg, filter, extend):
        """分类内容"""
        # 检查访问权限
        allowed, msg = self._check_access()
        if not allowed:
            return {"list": [{"vod_id": "locked", "vod_name": "🔒 访问受限", "vod_pic": "", "vod_remarks": msg}]}
        
        # 第二级：站点:分类ID -> 返回视频列表（支持完整路径和文件名）
        if ":" in tid:
            parts = tid.split(":", 1)
            filename = parts[0]
            sub_tid = parts[1]
            # 如果filename是完整路径，直接使用；否则尝试查找
            spider = self._load_source(filename)
            if spider and hasattr(spider, 'categoryContent'):
                try:
                    result = spider.categoryContent(sub_tid, pg, filter, extend)
                    if isinstance(result, str):
                        result = json.loads(result)
                    # 给每个视频ID加上站点前缀
                    if 'list' in result:
                        for v in result['list']:
                            if 'vod_id' in v:
                                v['vod_id'] = filename + "::" + str(v['vod_id'])
                    return result
                except Exception as e:
                    return {"list": [{"vod_id": "error", "vod_name": "❌ 加载失败", "vod_pic": "", "vod_remarks": str(e)[:100]}]}
            return {"list": []}
        
        # 第一级：站点路径 -> 返回该站点的分类列表
        filename = tid
        # 动态扫描模式，不检查NAME_MAP，直接尝试加载
        
        spider = self._load_source(filename)
        if spider and hasattr(spider, 'homeContent'):
            try:
                result = spider.homeContent(False)
                if isinstance(result, str):
                    result = json.loads(result)
                videos = []
                if 'class' in result and result['class']:
                    for c in result['class']:
                        videos.append({
                            "vod_id": filename + ":" + str(c.get('type_id', '')),
                            "vod_name": "📁 " + c.get('type_name', ''),
                            "vod_pic": "",
                            "vod_remarks": "点击进入视频列表",
                            "vod_tag": "folder"
                        })
                else:
                    videos.append({
                        "vod_id": "noclass",
                        "vod_name": "📂 该站点暂无分类",
                        "vod_pic": "",
                        "vod_remarks": "",
                    })
                return {"list": videos}
            except Exception as e:
                return {"list": [{"vod_id": "error", "vod_name": f"❌ 加载失败: {NAME_MAP.get(filename, filename)}", "vod_pic": "", "vod_remarks": str(e)[:100]}]}
        
        return {"list": [{"vod_id": "notfound", "vod_name": f"❌ 文件不存在: {filename}", "vod_pic": "", "vod_remarks": ""}]}
    
    # ==================== 详情 ====================
    def detailContent(self, ids):
        """详情页"""
        # 检查访问权限
        allowed, msg = self._check_access()
        if not allowed:
            return {"list": []}
        
        if not ids:
            return {"list": []}
        vid = ids[0] if isinstance(ids, list) else ids
        if "::" in str(vid):
            parts = str(vid).split("::", 1)
            filename = parts[0]
            real_vid = parts[1]
            # filename可能是完整路径，_load_source支持
            spider = self._load_source(filename)
            if spider and hasattr(spider, 'detailContent'):
                try:
                    result = spider.detailContent([real_vid])
                    if isinstance(result, str):
                        result = json.loads(result)
                    # 给播放地址的url部分加上站点前缀（格式：集数$站点::url）
                    # 注意：不能加在整个"集数$url"前面，否则TVBox传给playerContent的id不包含前缀
                    if 'list' in result:
                        for v in result['list']:
                            if 'vod_play_url' in v:
                                urls = str(v.get('vod_play_url', ''))
                                if urls:
                                    # 检测线路分隔符
                                    line_sep = '$$$' if '$$$' in urls else '$$'
                                    new_lines = []
                                    for line in urls.split(line_sep):
                                        if not line.strip():
                                            new_lines.append(line)
                                            continue
                                        # 每个线路里的集数用#分隔，格式：集数$url
                                        new_eps = []
                                        for ep in line.split('#'):
                                            if not ep.strip():
                                                new_eps.append(ep)
                                                continue
                                            if '$' in ep:
                                                ep_name, ep_url = ep.split('$', 1)
                                                new_eps.append(ep_name + '$' + filename + '::' + ep_url)
                                            else:
                                                new_eps.append(filename + '::' + ep)
                                        new_lines.append('#'.join(new_eps))
                                    v['vod_play_url'] = line_sep.join(new_lines)
                    return result
                except Exception as e:
                    return {"list": [{"vod_id": vid, "vod_name": "❌ 详情加载失败", "vod_pic": "", "vod_content": str(e)[:200]}]}
        return {"list": []}
    
    # ==================== 播放 ====================
    def playerContent(self, flag, id, vipFlags):
        """播放"""
        # 检查访问权限
        allowed, msg = self._check_access()
        if not allowed:
            return {"parse": 0, "url": "", "header": {}}
        
        if "::" in str(id):
            parts = str(id).split("::", 1)
            filename = parts[0]
            real_id = parts[1]
            # filename可能是完整路径，_load_source支持
            # 去掉flag$前缀
            if "$" in real_id:
                dollar_idx = real_id.index("$")
                url_part = real_id[dollar_idx+1:]
                if url_part.startswith("http") or url_part.startswith("/") or url_part.startswith("vod"):
                    real_id = url_part
            spider = self._load_source(filename)
            if spider and hasattr(spider, 'playerContent'):
                try:
                    result = spider.playerContent(flag, real_id, vipFlags)
                    if isinstance(result, str):
                        result = json.loads(result)
                    # 如果返回的是代理URL（包含127.0.0.1或proxy），添加wuye_site参数
                    if isinstance(result, dict) and "url" in result:
                        url = str(result.get("url", ""))
                        if ("127.0.0.1" in url or "proxy" in url) and "wuye_site=" not in url:
                            sep = "&" if "?" in url else "?"
                            result["url"] = url + sep + "wuye_site=" + filename
                    return result
                except Exception as e:
                    return {"parse": 0, "url": "", "header": {}, "error": str(e)[:100]}
        real_url = str(id)
        if "$" in real_url:
            dollar_idx = real_url.index("$")
            url_part = real_url[dollar_idx+1:]
            if url_part.startswith("http") or url_part.startswith("/"):
                real_url = url_part
        return {"parse": 0, "url": real_url, "header": {}}
    
    # ==================== 搜索（密码验证） ====================
    def searchContent(self, key, quick, pg=1):
        """搜索：用于密码验证"""
        config = _load_config()
        # 如果设置了密码，验证密码
        if config.get("password", ""):
            if str(key) == str(config["password"]):
                _set_authed()
                return {"list": [
                    {"vod_id": "success", "vod_name": "✅ 密码正确，访问已授权", "vod_pic": "", "vod_remarks": "有效期2小时，返回首页即可浏览"},
                    {"vod_id": "back", "vod_name": "← 返回午夜电影首页", "vod_pic": "", "vod_remarks": "点击返回"},
                ]}
            else:
                return {"list": [
                    {"vod_id": "wrong", "vod_name": "❌ 密码错误", "vod_pic": "", "vod_remarks": "请重新输入密码"},
                    {"vod_id": "tip", "vod_name": "💡 提示", "vod_pic": "", "vod_remarks": "在搜索框输入正确的访问密码"},
                ]}
        # 没有设置密码，直接搜索所有源
        all_videos = []
        for src in SOURCES:
            spider = self._load_source(src['filename'])
            if spider and hasattr(spider, 'searchContent'):
                try:
                    result = spider.searchContent(key, quick, pg)
                    if isinstance(result, str):
                        result = json.loads(result)
                    if 'list' in result:
                        for v in result['list']:
                            if 'vod_id' in v:
                                v['vod_id'] = src['filename'] + "::" + str(v['vod_id'])
                            all_videos.append(v)
                except:
                    pass
        return {"list": all_videos}
    
    def localProxy(self, param):
        """本地代理：根据URL参数判断是哪个站点的代理请求，路由到对应站点"""
        try:
            if isinstance(param, dict):
                target = param.get("url", "") or param.get("source", "") or ""
            else:
                target = str(param or "")
            # 从URL参数中提取站点信息（格式：wuye_site=站点文件名）
            import urllib.parse
            if "wuye_site=" in target:
                parsed = urllib.parse.urlparse(target)
                query_params = urllib.parse.parse_qs(parsed.query)
                site_name = query_params.get("wuye_site", [""])[0]
                if site_name and site_name in NAME_MAP:
                    spider = self._load_source(site_name)
                    if spider and hasattr(spider, 'localProxy'):
                        clean_url = target.replace("wuye_site=" + site_name, "")
                        clean_url = clean_url.replace("&&", "&").replace("?&", "?")
                        if clean_url.endswith("?"):
                            clean_url = clean_url[:-1]
                        if isinstance(param, dict):
                            new_param = dict(param)
                            new_param["url"] = clean_url
                        else:
                            new_param = clean_url
                        return spider.localProxy(new_param)
            return [404, "text/plain", b"not found"]
        except Exception as e:
            return [500, "text/plain", f"error: {str(e)}".encode("utf-8")]
    
    def destroy(self):
        pass
